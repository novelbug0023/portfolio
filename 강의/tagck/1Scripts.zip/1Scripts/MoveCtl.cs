﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;
using Photon.Realtime;
using UnityStandardAssets.Utility;
using TMPro;

public class MoveCtl : MonoBehaviourPunCallbacks,IPunObservable
{
    private float h, v;
    private Rigidbody rd;
    private Transform tr;
    public float speed = 10.0f;
    public float rotspeed = 600.0f;
    
    public TextMeshProUGUI nickName;

    public Image hpBar;

    private float currtHp = 100.0f;
    private float initHp = 100.0f;
    private bool isdie = false;
    public float respawnTime = 3.0f;

    //public float currPos;
    //public float currRot;
    //public LayerMask layer;


    // Start is called before the first frame update
    void Start()
    {
        rd = GetComponent<Rigidbody>();
        rd.centerOfMass = new Vector3(0,-1.5f,0); //무개 중심점을 변경.

        tr = GetComponent<Transform>();
        if (photonView.IsMine)
        {
            Camera.main.GetComponent<SmoothFollow>().target = tr.Find("cam").transform;
            rd.mass = 50000;
        }
        else
        {
            GetComponent<Rigidbody>().isKinematic = true;   //물리 충돌을 일어나지 않도록 한다.
        }
        nickName.text = photonView.Owner.NickName;
    }

    // Update is called once per frame
    void Update()
    {
        if (photonView.IsMine && !isdie)//본인이거나 죽지 않았으면 조작
        {
            h = Input.GetAxis("Horizontal");
            v = Input.GetAxis("Vertical");

            tr.Translate(Vector3.forward * v * speed * Time.deltaTime);
            tr.Rotate(Vector3.up * h * rotspeed * Time.deltaTime);
        }
        else
        {
            if ((tr.position - currPos).sqrMagnitude >= 10.0f * 10.0f)
            {
                tr.position = currPos;
                tr.rotation = currRot;
            }
            else
            {
                tr.position = Vector3.Lerp(tr.position, currPos, Time.deltaTime * 10.0f);
                tr.rotation = Quaternion.Slerp(tr.rotation, currRot, Time.deltaTime * 10.0f);
            }
        } 
        //if (!photonView.IsMine){    return;     }
    }
    //포탄에 맞았을 경우
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.CompareTag("CANNON") && !isdie)
        {
            int actorNumber = collision.gameObject.GetComponent<Cannonshot>().acterNumber;
            string hitter = GetNicknamebyActorNumber(actorNumber);

            currtHp -= 20.0f;
            hpBar.fillAmount = currtHp / initHp;
            if (photonView.IsMine && currtHp <= 0.0f)
            {
                isdie = true;
                Debug.Log("죽었음"+hitter);
                StartCoroutine(RespawnPlayer(actorNumber));
            }
        }
        
    }
    IEnumerator RespawnPlayer(int actorNumber)
    {
        Transform followTr = null;
        foreach (GameObject tank in GameObject.FindGameObjectsWithTag("TANK"))
        {
            if (tank.GetComponent<PhotonView>().OwnerActorNr == actorNumber)
            {
                followTr = tank.transform.Find("cam").transform;
            }
        }
        Camera.main.GetComponent<SmoothFollow>().target = followTr;

        yield return new WaitForSeconds(respawnTime);
        Camera.main.GetComponent<SmoothFollow>().target = tr.Find("cam").transform;
        currtHp = 100.0f;
        hpBar.fillAmount = 1.0f;
        isdie = false;
    }
    //닉네임 가져오기
    string GetNicknamebyActorNumber(int actorNumber)
    {
        //지금 현재 방에 접속한 사람의 닉네임을 가져온다.
        //PlayerListOther 자기 자신을 제외한 나머지 다 가져오기
        foreach (Player player in PhotonNetwork.PlayerListOthers)
        {
            if (player.ActorNumber == actorNumber)
            {
                return player.NickName;
            }

        }
        return "Ghost";
    }

    private Vector3 currPos; //실시간으로 전송 하고 받는 변수
    private Quaternion currRot; //실시간으로 받는 변수
    private Image currrHP;

    public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
    {
        if (stream.IsWriting)
        {
            stream.SendNext(tr.position);
            stream.SendNext(tr.rotation);
            //stream.SendNext(hpBar.fillAmount);
        }
        else
        {
            currPos = (Vector3)stream.ReceiveNext();
            currRot = (Quaternion)stream.ReceiveNext();
            //currrHP = (Image)stream.ReceiveNext();
        }
        //throw new System.NotImplementedException();

    }

    

}
