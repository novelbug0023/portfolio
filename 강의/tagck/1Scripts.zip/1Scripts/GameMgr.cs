﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine.SceneManagement;

public class GameMgr : MonoBehaviourPunCallbacks
{
    public Text MsgList;
    public InputField ifSendMsg;

    public Text PlayerCount;


    // Start is called before the first frame update
    void Start()
    {
        CreateTanck();
        //PhotonNetwork의 데이터 통신을 다시 연결해 준다.
        PhotonNetwork.IsMessageQueueRunning = true;
        Invoke("CheckPlayerCount",0.5f);

    }
    void CreateTanck()
    {
        Transform[] points = GameObject.Find("Spawnpoint").GetComponentsInChildren<Transform>();

        int idx = Random.Range(1, points.Length);
        PhotonNetwork.Instantiate("Tank", points[idx].position, Quaternion.identity);
    }
   
    public void OnSendChatMsg()
    {
        string msg = string.Format("[{0}]{1}", PhotonNetwork.LocalPlayer.NickName, ifSendMsg.text);
        photonView.RPC("ReceMsg", RpcTarget.OthersBuffered, msg);
        ReceMsg(msg);
    }
    [PunRPC]
    void ReceMsg(string msg)
    {
        MsgList.text += "\n" + msg;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void CheckPlayerCount()
    {
        int CurrPlayer = PhotonNetwork.PlayerList.Length;
        int MaxPlayer = PhotonNetwork.CurrentRoom.MaxPlayers;
        PlayerCount.text = string.Format("[{0}/{1}]", CurrPlayer, MaxPlayer);
    }
    public void OnExitClick()
    {
        PhotonNetwork.LeaveRoom();
    }
    public override void OnLeftRoom()
    {
        //base.OnLeftRoom();
        SceneManager.LoadScene("Lobby");
    }
    public override void OnPlayerEnteredRoom(Player newPlayer)
    {
        //base.OnPlayerEnteredRoom(newPlayer);
        CheckPlayerCount();
        string msg = string.Format("\n<color=#00ff00>[{0}]님이 GGG의 전장으로 출전 하셨습니다.</color>", newPlayer.NickName);
        ReceMsg(msg);
    }
    public override void OnPlayerLeftRoom(Player otherPlayer)
    {
        //base.OnPlayerLeftRoom(otherPlayer);
        CheckPlayerCount();
        string msg = string.Format("\n<color=#ff0000>[{0}]님이 GGG의 전장에서 이탈 하셨습니다.</color>", otherPlayer.NickName);
        ReceMsg(msg);
    }
}
