﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine.Windows;

public class FILECannon : MonoBehaviourPunCallbacks
{
    public Transform firePos;
    public GameObject cannon;
    public AudioClip fireSfx;

    private AudioSource _audio;

    private void Start()
    {
        _audio = this.gameObject.AddComponent<AudioSource>();
    }


    // Update is called once per frame
    void Update()
    {
        if (!photonView.IsMine) { return; }
        if (Input.GetMouseButtonDown(0))
        {
            int actorNumber = photonView.Owner.ActorNumber;
            photonView.RPC("Fire", RpcTarget.Others, actorNumber);
            Fire(actorNumber);

        }
    }
    [PunRPC]
    void Fire(int Number)
    {
        _audio.PlayOneShot(fireSfx, 0.8f);
        GameObject obj = Instantiate(cannon, firePos.position, firePos.rotation);
        obj.GetComponent<Cannonshot>().acterNumber = Number;
        //Instantiate(cannon, firePos.position, firePos.rotation);
    }
}
