﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;
using Photon.Realtime;
using TMPro;
using UnityEngine.SceneManagement;


public class PhotonInit : MonoBehaviourPunCallbacks
{
    public enum ActivePanel
    {
        LOGIN = 0,
        ROOM = 1
    }
    public ActivePanel activePanel = ActivePanel.LOGIN;

    public string gameversin = "1.0";
    public string userID = "tanker";
    public byte maxPlayer = 20;

    public TMPro.TMP_InputField txtUserID;
    public TMP_InputField txtRoomName;

    public GameObject[] Panels;

    public GameObject room;
    public Transform gridTr;
    public Text roomText;

    private void Awake()
    {
        PhotonNetwork.AutomaticallySyncScene = true;
    }


    // Start is called before the first frame update
    void Start()
    {
        txtUserID.text = PlayerPrefs.GetString("USER_ID","USER_" + Random.Range(1,999));
        txtRoomName.text = PlayerPrefs.GetString("ROOM_NAME", "ROOM_" + Random.Range(1, 999));

        if (PhotonNetwork.IsConnected)
        {
            ChangePanel(ActivePanel.ROOM);
        }

        //PhotonNetwork.GameVersion = this.gameversin; 
        //PhotonNetwork.NickName = userID;
        //PhotonNetwork.ConnectUsingSettings();

    }
    #region SELF_CALLBACK_FUNCTIONS 
    public void OnLogin()
    {
        PhotonNetwork.GameVersion = this.gameversin;
        PhotonNetwork.NickName = txtUserID.text;
        PhotonNetwork.ConnectUsingSettings();
        PlayerPrefs.SetString("USER_ID", PhotonNetwork.NickName);
        ChangePanel(ActivePanel.ROOM);
    }
    public void OnCreateRoomClick()
    {
        PhotonNetwork.CreateRoom(txtRoomName.text, new RoomOptions {MaxPlayers = this.maxPlayer});
    }
    public void OnjoinRandomRoomClick()
    {
        PhotonNetwork.JoinRandomRoom();
    }

    #endregion
    private void ChangePanel(ActivePanel panel)
    {
        foreach (GameObject _panel in Panels)
        {
            Debug.Log(Panels);
            _panel.SetActive(false);
        }
        Panels[(int)panel].SetActive(true);
       
    }
    #region PHOTON_CALLBACK_FUNCTIONS 

    public override void OnConnectedToMaster()
    {
        //base.OnConnectedToMaster();
        Debug.Log("접속연결");
        PhotonNetwork.JoinLobby();
        //PhotonNetwork.JoinRandomRoom();
    }

    public override void OnJoinedLobby()
    {
        //base.OnJoinedLobby();
        Debug.LogWarning("로비 입장");
    }

    public override void OnJoinRandomFailed(short returnCode, string message)
    {
        //base.OnJoinRandomFailed(returnCode, message);
        Debug.Log("랜덤룸 입장 실패");
        PhotonNetwork.CreateRoom(null, new RoomOptions { MaxPlayers = this.maxPlayer });
    }
    public override void OnJoinedRoom()
    {
        //base.OnJoinedLobby();
        Debug.Log("룸입장");
        //PhotonNetwork.Instantiate("Tank", new Vector3(500.0f, 3.0f, 500.0f), Quaternion.identity);
        //CreateTank();
        PhotonNetwork.IsMessageQueueRunning = false;
        SceneManager.LoadScene("play");
    }

    public override void OnRoomListUpdate(List<RoomInfo> roomList)
    {
        //base.OnRoomListUpdate(roomList);
        foreach (GameObject obj in GameObject.FindGameObjectsWithTag("ROOM"))
        {
            Destroy(obj);
        }
        foreach (RoomInfo roominfo in roomList)
        {
            GameObject _room = Instantiate(room, gridTr);
            RoomData roomData = _room.GetComponent<RoomData>();
            roomData.roomName = roominfo.Name;
            roomData.maxPlayer = roominfo.MaxPlayers;
            roomData.PlayerCount = roominfo.PlayerCount;
            roomData.UpDateInfo();
            roomData.GetComponent<Button>().onClick.AddListener
            (
                delegate
                {
                    onClickRoom(roomData.roomName);
                }
            );
        }
        

    }
    #endregion

    void onClickRoom(string roomName)
    {
        PhotonNetwork.NickName = txtUserID.text;
        PhotonNetwork.JoinRoom(roomName, null);
        PlayerPrefs.SetString("USER_ID", PhotonNetwork.NickName);
    }

    void CreateTank()
    {
        Transform[] posints = GameObject.Find("Spawnpoint").GetComponentsInChildren<Transform>();
        int idx = Random.Range(1, posints.Length);
        PhotonNetwork.Instantiate("tank", posints[idx].position, Quaternion.identity);
    }
    
}
