﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cannonshot : MonoBehaviour
{
    public float speed = 20.0f;
    public float force = 2000.0f;
    public GameObject expEffect;
    public int acterNumber = -1; //접속 순서에 따른 플레이어 넘버.

    //private Transform tr;
    // Start is called before the first frame update
    void Start()
    {
        GetComponent<Rigidbody>().AddRelativeForce(Vector3.forward * force);
        //tr = GetComponent<Transform>();
        Destroy(this.gameObject,10.0f);
    }
    private void OnCollisionEnter(Collision collision)
    {
        GameObject Obj = Instantiate(expEffect, transform.position, Quaternion.identity);
        Destroy(this.gameObject);
        Destroy(Obj,2.0f);
        
    }
    // Update is called once per frame
    void Update()
    {
        //tr.Translate(Vector3.forward * speed * Time.deltaTime);
    }
}
