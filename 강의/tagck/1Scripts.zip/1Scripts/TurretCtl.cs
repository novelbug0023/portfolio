﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using Photon.Pun;
using Photon.Realtime;

public class TurretCtl : MonoBehaviourPunCallbacks
{
    private Transform tr;
    public float rotspeed = 10.0f;

    private RaycastHit hit;

    // Start is called before the first frame update
    void Start()
    {
        tr = GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        if (!photonView.IsMine) { return; }
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        Debug.DrawRay(ray.origin, ray.direction * 50.0f, Color.green);
        if (Physics.Raycast(ray, out hit, Mathf.Infinity, 1 << 8)) 
        {
            Vector3 localpos = tr.InverseTransformPoint(hit.point);
            float angle = Mathf.Atan2(localpos.x, localpos.z) * Mathf.Rad2Deg;
            tr.Rotate(0, angle * rotspeed * Time.deltaTime, 0);
        }
        
    }
    //private Vector3 currPOS;
   
}
