﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Billboard : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }
    void Update()
    {
        //스크립트가 ON상태일 때
        //매 프레임마다 호출
    }
    // Update is called once per frame
    private void FixedUpdate()
    {
        //프리엠 기반 설정된 프레임 간격으로 호출;
        //물리엔진 처리에 사용.
    }
    private void LateUpdate()
    {
        //Update 함수가 다 호출된 후에 마지막으로 호출..
        //카메라가 따라가는 오브젝트가 업데이트 함수안에서 움직이는 경우도 있음
        transform.LookAt(Camera.main.transform.position);
    }
    
}
