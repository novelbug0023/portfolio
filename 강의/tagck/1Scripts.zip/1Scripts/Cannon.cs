﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;
using Photon.Realtime;

public class Cannon : MonoBehaviourPunCallbacks
{
    private Transform tr;
    public float rotSpeed = 300.0f;

    // Start is called before the first frame update
    void Start()
    {
        tr = GetComponent<Transform>();

    }

    // Update is called once per frame
    void Update()
    {
        if (!photonView.IsMine) 
        {
            return;
        }
        tr.Rotate(Vector3.right * Input.GetAxis("Mouse ScrollWheel") * rotSpeed * Time.deltaTime);
    }
}
