using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pyramid : MonoBehaviour
{
    Vector3 normal;
    // Start is called before the first frame update
    void Start()
    {
        MeshFilter meshFilter = GetComponent<MeshFilter>();
        Mesh mesh = new Mesh();

        List<Vector3> vertexbuffer = new List<Vector3>();
        //0~3
        vertexbuffer.Add(new Vector3(0f, 0.5f, 0f));
        vertexbuffer.Add(new Vector3(0f, 0.5f, 0f));
        vertexbuffer.Add(new Vector3(0f, 0.5f, 0f));
        vertexbuffer.Add(new Vector3(0f, 0.5f, 0f));
        //4~6
        vertexbuffer.Add(new Vector3(-0.5f, 0f, 0.5f));
        vertexbuffer.Add(new Vector3(-0.5f, 0f, 0.5f));
        vertexbuffer.Add(new Vector3(-0.5f, 0f, 0.5f));
        //7~9
        vertexbuffer.Add(new Vector3(0.5f, 0f, 0.5f));
        vertexbuffer.Add(new Vector3(0.5f, 0f, 0.5f));
        vertexbuffer.Add(new Vector3(0.5f, 0f, 0.5f));
        //10~12
        vertexbuffer.Add(new Vector3(0.5f, 0f, -0.5f));
        vertexbuffer.Add(new Vector3(0.5f, 0f, -0.5f));
        vertexbuffer.Add(new Vector3(0.5f, 0f, -0.5f));
        //13~15
        vertexbuffer.Add(new Vector3(-0.5f, 0f, -0.5f));
        vertexbuffer.Add(new Vector3(-0.5f, 0f, -0.5f));
        vertexbuffer.Add(new Vector3(-0.5f, 0f, -0.5f));
        


        List<int> indexBuffer = new List<int>();
        //0
        indexBuffer.Add(0);
        indexBuffer.Add(10);
        indexBuffer.Add(13);
        //1
        indexBuffer.Add(1);
        indexBuffer.Add(14);
        indexBuffer.Add(4);
        //2
        indexBuffer.Add(2);
        indexBuffer.Add(5);
        indexBuffer.Add(7);
        //3
        indexBuffer.Add(3);
        indexBuffer.Add(8);
        indexBuffer.Add(11);
        //4
        indexBuffer.Add(9);
        indexBuffer.Add(15);
        indexBuffer.Add(11);
        //5
        indexBuffer.Add(6);
        indexBuffer.Add(15);
        indexBuffer.Add(9);

        Vector3[] nomals = new Vector3[vertexbuffer.Count];
        //Vector3 normal;
        //0
        normal = GetNoraml(vertexbuffer[0], vertexbuffer[10], vertexbuffer[13]);
        nomals[0] = normal;
        nomals[10] = normal;
        nomals[13] = normal;
        //1
        normal = GetNoraml(vertexbuffer[1], vertexbuffer[14], vertexbuffer[4]);
        nomals[1] = normal;
        nomals[14] = normal;
        nomals[4] = normal;
        //2
        normal = GetNoraml(vertexbuffer[2], vertexbuffer[5], vertexbuffer[7]);
        nomals[2] = normal;
        nomals[5] = normal;
        nomals[7] = normal;
        //3
        normal = GetNoraml(vertexbuffer[1], vertexbuffer[14], vertexbuffer[4]);
        nomals[1] = normal;
        nomals[14] = normal;
        nomals[4] = normal;
        //4
        normal = GetNoraml(vertexbuffer[9], vertexbuffer[15], vertexbuffer[12]);
        nomals[9] = normal;
        nomals[15] = normal;
        nomals[12] = normal;
        //5
        normal = GetNoraml(vertexbuffer[6], vertexbuffer[15], vertexbuffer[9]);
        nomals[6] = normal;
        nomals[15] = normal;
        nomals[9] = normal;

        //Vector3 dir1 = vertexbuffer[0] - vertexbuffer[13];
        //Vector3 dir2 = vertexbuffer[0] - vertexbuffer[13];


        mesh.vertices = vertexbuffer.ToArray();
        mesh.triangles = indexBuffer.ToArray();
        mesh.normals = nomals;

        meshFilter.mesh = mesh;
        //-0.5,0,-0.5//-0.6,0,0.6//0.6,0,0.6//0.5,0,-0.5//0,1,0//
        // �� 3���� �̷������ ���� ������
    }
    Vector3 GetNoraml(Vector3 v1, Vector3 v2, Vector3 v3)
    {
        Vector3 noraml = new Vector3();

        Vector3 dir1 = v1 - v2;
        Vector3 dir2 = v2 - v3;

        noraml = Vector3.Cross(dir1, dir2);
        noraml.Normalize();

        return noraml;
    }
    // Update is called once per frame
    void Update()
    {
        transform.Rotate(Vector3.up, 10*Time.deltaTime);
    }
}
