using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tesr : MonoBehaviour
{
    
    // Start is called before the first frame update
    void Start()
    {
        MeshFilter meshFilter = GetComponent<MeshFilter>();
        Mesh mesh = new Mesh();

        List<Vector3> vertexbuffer = new List<Vector3>();

        //0
        vertexbuffer.Add(new Vector3(-0.5f, 0.5f, 0.0f));
        //1
        vertexbuffer.Add(new Vector3(0.5f, 0.5f, 0.0f));
        //2
        vertexbuffer.Add(new Vector3(0.5f, -0.5f, 0.0f));
        //3
        vertexbuffer.Add(new Vector3(-0.5f, -0.5f, 0.0f));
        List<int> indexBuffer = new List<int>();

        //0
        indexBuffer.Add(0);
        indexBuffer.Add(1);
        indexBuffer.Add(2);
        //1
        indexBuffer.Add(0);
        indexBuffer.Add(2);
        indexBuffer.Add(3);
        
        

        mesh.vertices = vertexbuffer.ToArray();
        mesh.triangles = indexBuffer.ToArray();

        meshFilter.mesh = mesh;
        //indexBuffer.Add(13);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
