﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(CharacterMovement))]
public class PlayerControl : MonoBehaviour
{
    CharacterMovement myMovement;
    // Start is called before the first frame update
    private void Awake()
    {
        myMovement = this.GetComponent<CharacterMovement>();  
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetMouseButtonDown(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if(Physics.Raycast(ray,out hit))
            {
                myMovement.MovePosition(hit.point);
            }
        }
    }
}
