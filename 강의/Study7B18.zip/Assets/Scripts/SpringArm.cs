﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpringArm : MonoBehaviour
{
    public float RotSpeed = 180.0f;
    public float ZoomSpeed = 10.0f;

    public Vector2 LookUpArea = new Vector2(-60f,80f);
    public Vector2 ZoomArea = new Vector2(1f, 10f);
    float Dist = 5f;

    public Transform trCamera;
    // Start is called before the first frame update
    void Start()
    {
        Dist = Mathf.Abs(trCamera.localPosition.z);
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetMouseButton(1))
        {
            //LookUp
            Vector3 rot = this.transform.rotation.eulerAngles;
            float delta = -Input.GetAxis("Mouse Y") * RotSpeed * Time.deltaTime;
            rot.x += delta;
            if (rot.x > 180f) rot.x -= 360.0f;
            rot.x = Mathf.Clamp(rot.x, LookUpArea.x,LookUpArea.y);

            //LeftRight
            delta = Input.GetAxis("Mouse X") * RotSpeed * Time.deltaTime;
            rot.y += delta;

            this.transform.rotation = Quaternion.Euler(rot);            
        }

        if (Input.GetAxis("Mouse ScrollWheel") > Mathf.Epsilon ||
                Input.GetAxis("Mouse ScrollWheel") < -Mathf.Epsilon)
        {
            float delta = -Input.GetAxis("Mouse ScrollWheel") * ZoomSpeed * Time.deltaTime;
            Dist = Mathf.Clamp(Dist + delta, ZoomArea.x, ZoomArea.y);
            trCamera.localPosition = new Vector3(0, 0, -Dist);
        }
    }
}
