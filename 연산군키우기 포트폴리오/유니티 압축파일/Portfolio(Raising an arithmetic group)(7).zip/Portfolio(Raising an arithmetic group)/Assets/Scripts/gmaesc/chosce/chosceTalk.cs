using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu(fileName = "ChosceData", menuName = "Scriptabl eObject/Chosece Data", order = int.MaxValue)]
public class chosceTalk : ScriptableObject
{
    public string dialogueName;
    public string[] lovessdialogues;
    public string lovesdialogue_name;
    public int lovepoint;
    public Image lovescharactorimage;

}
