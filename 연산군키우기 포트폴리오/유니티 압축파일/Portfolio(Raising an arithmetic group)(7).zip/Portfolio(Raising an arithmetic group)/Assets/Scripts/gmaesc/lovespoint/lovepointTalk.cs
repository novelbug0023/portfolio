using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu(fileName = "lovepointTalkData", menuName = "Scriptabl eObject/lovepointTalk Data", order = int.MaxValue)]
public class lovepointTalk : ScriptableObject
{
    public int chosceAdd;
    public string dialogueName;
    public string[] lovessdialogues;
    public string lovesdialogue_name;
    public bool ischosce = false;
    public Image lovescharactorimage;
}
