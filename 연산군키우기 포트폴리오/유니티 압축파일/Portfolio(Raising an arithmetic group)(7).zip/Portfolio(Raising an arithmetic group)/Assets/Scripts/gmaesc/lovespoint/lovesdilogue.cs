using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class lovepointdialogue
{
    #region ȣ���� ��ȭ
    public int chosceAdd;
    public string dialogueName;
    public string[] lovessdialogues;
    public string lovesdialogue_name;
    public Image lovescharactorimage;
    #endregion
}
public class lovesdilogue : MonoBehaviour
{
    #region �̱���
    private static lovesdilogue instance = null;
    void Awake()
    {
        if (null == instance)
        {
            //�� Ŭ���� �ν��Ͻ��� ź������ �� �������� instance�� ���ӸŴ��� �ν��Ͻ��� ������� �ʴٸ�, �ڽ��� �־��ش�.
            instance = this;

            //�� ��ȯ�� �Ǵ��� �ı����� �ʰ� �Ѵ�.
            //gameObject�����ε� �� ��ũ��Ʈ�� ������Ʈ�μ� �پ��ִ� Hierarchy���� ���ӿ�����Ʈ��� ��������, 
            //���� �򰥸� ������ ���� this�� �ٿ��ֱ⵵ �Ѵ�.
            DontDestroyOnLoad(this.gameObject);
        }
        else
        {
            //���� �� �̵��� �Ǿ��µ� �� ������ Hierarchy�� GameMgr�� ������ ���� �ִ�.
            //�׷� ��쿣 ���� ������ ����ϴ� �ν��Ͻ��� ��� ������ִ� ��찡 ���� �� ����.
            //�׷��� �̹� ���������� instance�� �ν��Ͻ��� �����Ѵٸ� �ڽ�(���ο� ���� GameMgr)�� �������ش�.
            Destroy(this.gameObject);
        }
    }
    public static lovesdilogue Instance
    {
        get
        {
            if (null == instance)
            {
                return null;
            }
            return instance;
        }
    }
    #endregion
    public lovepointdialogue[] lovesdiloguepoint;
    public Text dialogueText;
    public Text NameText;
    public GameObject dialogue_box;
    public GameObject dialogueNextBt;
    public int dialogueindex = 0;
    public int nextDialogue = 0;
    public string sdialogue;
    public bool chose = false;

    // Start is called before the first frame update
    void Start()
    {
        if (GameDataBassManager.Instance.databass.lovedialogueindex == 0)
        {
            GameDataBassManager.Instance.databass.lovedialogueindex = 0;
        }
    }

    // Update is called once per frame
    void Update()
    {

    }
    public void dialogue()
    {
        lovepointTalk();
        sdialogue = lovePointDatabass.Instance.LovepointDb.loveTalk.lovessdialogues[nextDialogue];
        StartCoroutine(dialogueTime());
    }
    IEnumerator dialogueTime()
    {
        if (GameDataBassManager.Instance.databass.lovedialogueindex == 0 || GameDataBassManager.Instance.databass.lovepoint == 0)
        {
            NameText.text = lovePointDatabass.Instance.LovepointDb.loveTalk.lovesdialogue_name;
        }
        if (GameDataBassManager.Instance.databass.lovedialogueindex > 0 && GameDataBassManager.Instance.databass.lovepoint != 0)
        {
            //NameText.text = lovePointDatabass.Instance.LovepointDb.loveTalks[lovePointDatabass.Instance.LovepointDb.lovep].lovesdialogue_name;
        }

        #region Ÿ����
        yield return new WaitForSeconds(0.5f);
        for (int i = 0; i <= sdialogue.Length; i++)
        {
            dialogueText.text = sdialogue.Substring(0, i);
            yield return new WaitForSeconds(0.1f);
        }
        dialogueNextBt.SetActive(true);
        #endregion
    }
    public void nextDialogueBt()
    {
        if (nextDialogue + 1 >= lovePointDatabass.Instance.LovepointDb.loveTalk.lovessdialogues.Length)
        {
            if (lovePointDatabass.Instance.LovepointDb.loveTalk.ischosce == true)
            {
                chose = true;
                ChioscelovepointTalk();
                dialogueNextBt.SetActive(false);
                nextDialogue = 0;
                choshecDialogue.Instance.showchosee();
            }
            else
            {
                endDialogue();
            }
            //lovesindex();
        }
        else if (nextDialogue < lovePointDatabass.Instance.LovepointDb.loveTalk.lovessdialogues.Length)
        {
            Debug.Log("������ȭ");
            dialogueNextBt.SetActive(false);
            nextDialogue++;
            dialogue();

            //StartCoroutine(dialogueTime());
        }

        #region Ȥ�� �ʿ� �Ҽ� �� ���� ���
        //if (GameDataBassManager.Instance.databass.lovedialogueindex > 0 && GameDataBassManager.Instance.databass.lovepoint > 0)
        //{
        //    if (nextDialogue + 1 >= lovePointDatabass.Instance.LovepointDb.loveTalks[lovePointDatabass.Instance.LovepointDb.lovep].lovessdialogues.Length)
        //    {
        //        if (lovePointDatabass.Instance.LovepointDb.loveTalks[lovePointDatabass.Instance.LovepointDb.lovep].ischosce == true)
        //        {
        //            chose = true;
        //            dialogueNextBt.SetActive(false);
        //            nextDialogue = 0;
        //            choshecDialogue.Instance.showchosee();
        //        }
        //        if (lovePointDatabass.Instance.LovepointDb.loveTalks[lovePointDatabass.Instance.LovepointDb.lovep].ischosce == false)
        //        {
        //            endDialogue();
        //            lovePointDatabass.Instance.LovepointDb.lovep++;
        //        }
        //        //lovesindex();
        //    }
        //    else if (nextDialogue < lovePointDatabass.Instance.LovepointDb.loveTalks[lovePointDatabass.Instance.LovepointDb.lovep].lovessdialogues.Length)
        //    {
        //        Debug.Log("������ȭ");
        //        dialogueNextBt.SetActive(false);
        //        nextDialogue++;
        //        dialogue();

        //        //StartCoroutine(dialogueTime());
        //    }
        //}   
        #endregion
    }
    void endDialogue()
    {
        nextDialogue = 0;
        StopCoroutine(dialogueTime());
        GameDataBassManager.Instance.databass.lovedialogueindex++;
        //dialogueindex++;
        dialogue_box.SetActive(false);
        dialogueNextBt.SetActive(false);
    }

    #region ȣ���� ������ ��ȭ 
    void lovepointTalk()
    {
        if (GameDataBassManager.Instance.databass.lovedialogueindex == 2)
        {
            lovePointDatabass.Instance.LovepointDb.loveTalk = lovePointDatabass.Instance.LovepointDb.loveTalkBox[2];
        }
        if (GameDataBassManager.Instance.databass.lovedialogueindex == 1)
        {
            lovePointDatabass.Instance.LovepointDb.loveTalk = lovePointDatabass.Instance.LovepointDb.loveTalkBox[1];
        }
        if (GameDataBassManager.Instance.databass.lovedialogueindex == 0)
        {
            lovePointDatabass.Instance.LovepointDb.loveTalk = lovePointDatabass.Instance.LovepointDb.loveTalkBox[0];
        }
    }
    //������ ȣ������ ���� �ٸ��� ������
    void ChioscelovepointTalk()
    {
        if (GameDataBassManager.Instance.databass.lovepoint == 5)
        {
            chosceDatabass.Instance.ChosceDb.chosceTalk[0] = chosceDatabass.Instance.ChosceDb.chosceTalksBox[3];
            chosceDatabass.Instance.ChosceDb.chosceTalk[1] = chosceDatabass.Instance.ChosceDb.chosceTalksBox[4];
            chosceDatabass.Instance.ChosceDb.chosceTalk[2] = chosceDatabass.Instance.ChosceDb.chosceTalksBox[5];
        }
        if (GameDataBassManager.Instance.databass.lovedialogueindex == 1)
        {
            chosceDatabass.Instance.ChosceDb.chosceTalk[0] = chosceDatabass.Instance.ChosceDb.chosceTalksBox[0];
            chosceDatabass.Instance.ChosceDb.chosceTalk[1] = chosceDatabass.Instance.ChosceDb.chosceTalksBox[1];
            chosceDatabass.Instance.ChosceDb.chosceTalk[2] = chosceDatabass.Instance.ChosceDb.chosceTalksBox[2];
        }
    }
    #endregion

}
