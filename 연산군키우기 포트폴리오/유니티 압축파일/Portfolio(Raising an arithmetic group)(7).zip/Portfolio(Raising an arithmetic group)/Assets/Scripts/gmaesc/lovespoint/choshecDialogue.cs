using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class choshecDialogue : MonoBehaviour
{
    #region �̱���
    private static choshecDialogue instance = null;
    void Awake()
    {
        if (null == instance)
        {
            //�� Ŭ���� �ν��Ͻ��� ź������ �� �������� instance�� ���ӸŴ��� �ν��Ͻ��� ������� �ʴٸ�, �ڽ��� �־��ش�.
            instance = this;

            //�� ��ȯ�� �Ǵ��� �ı����� �ʰ� �Ѵ�.
            //gameObject�����ε� �� ��ũ��Ʈ�� ������Ʈ�μ� �پ��ִ� Hierarchy���� ���ӿ�����Ʈ��� ��������, 
            //���� �򰥸� ������ ���� this�� �ٿ��ֱ⵵ �Ѵ�.
            DontDestroyOnLoad(this.gameObject);
        }
        else
        {
            //���� �� �̵��� �Ǿ��µ� �� ������ Hierarchy�� GameMgr�� ������ ���� �ִ�.
            //�׷� ��쿣 ���� ������ ����ϴ� �ν��Ͻ��� ��� ������ִ� ��찡 ���� �� ����.
            //�׷��� �̹� ���������� instance�� �ν��Ͻ��� �����Ѵٸ� �ڽ�(���ο� ���� GameMgr)�� �������ش�.
            Destroy(this.gameObject);
        }
    }
    public static choshecDialogue Instance
    {
        get
        {
            if (null == instance)
            {
                return null;
            }
            return instance;
        }
    }
    #endregion
    public GameObject[] choseBt;
    public GameObject choseBtprefab;
    public Transform choseBtpos;

    public GameObject choseNextbt;
    public int dialogueindex = 0;

    public int dialogueName;
    //public string sdialogue;
    int chosceNum = 0;
    public int addChosce = 0;
    public void showchosee()
    {
        if (lovesdilogue.Instance.chose == true)
        {
            lovesdilogue.Instance.nextDialogue = 0;
            addChoseInstance(lovesdilogue.Instance.lovesdiloguepoint[lovesdilogue.Instance.dialogueindex].chosceAdd);
            for (int i = 0; i < choseBt.Length; i++)
            {
                //if (i > chosceDatabass.Instance.ChosceDb.chosceTalk.Length) { break; }
                int k = i;
                choseBt[i].GetComponent<Button>().onClick.AddListener(() => choshesBT(k));
                #region ���ٽ��� �ȉ��� ��
                //switch(i)
                //{
                //    case 0:
                //        choseBt[i].GetComponent<Button>().onClick.AddListener(TestBT1);
                //        break;
                //    case 1:
                //        choseBt[i].GetComponent<Button>().onClick.AddListener(TestBT2);
                //        break;
                //    case 2:
                //        choseBt[i].GetComponent<Button>().onClick.AddListener(TestBT3);
                //        break;
                //}               
                //Debug.Log(choseBt[i].name);
                #endregion
                choseBt[i].GetComponentInChildren<Text>().text = chosceDatabass.Instance.ChosceDb.chosceTalk[i].dialogueName;
                //chosceNum++;
            }

        }

    }

    void TestBT1()
    {
        choshesBT(0);
    }

    void TestBT2()
    {
        choshesBT(1);
    }

    void TestBT3()
    {
        choshesBT(2);
    }

    public void addChoseInstance(int choseInstanceIndex)
    {
        switch (choseInstanceIndex)
        {
            case 1:
                choseBt = new GameObject[1];
                choseBt[0] = Instantiate(choseBtprefab);
                choseBt[0].transform.SetParent(choseBtpos.transform);
                choseBt[0].transform.localPosition = Vector3.zero;
                break;
            case 2:
                choseBt = new GameObject[2];
                choseBt[0] = Instantiate(choseBtprefab);
                choseBt[0].transform.SetParent(choseBtpos.transform);
                choseBt[0].transform.localPosition = Vector3.zero;
                choseBt[1] = Instantiate(choseBtprefab);
                choseBt[1].transform.SetParent(choseBtpos.transform);
                choseBt[1].transform.localPosition = Vector3.zero;
                break;
            case 3:
                choseBt = new GameObject[3];
                choseBt[0] = Instantiate(choseBtprefab);
                choseBt[0].transform.SetParent(choseBtpos.transform);
                choseBt[0].transform.localPosition = Vector3.zero;
                choseBt[0].name = "ChoseBt0";
                choseBt[1] = Instantiate(choseBtprefab);
                choseBt[1].transform.SetParent(choseBtpos.transform);
                choseBt[1].transform.localPosition = Vector3.zero;
                choseBt[1].name = "ChoseBt1";
                choseBt[2] = Instantiate(choseBtprefab);
                choseBt[2].transform.SetParent(choseBtpos.transform);
                choseBt[2].transform.localPosition = Vector3.zero;
                choseBt[2].name = "ChoseBt2";
                break;
            case 4:
                choseBt = new GameObject[4];
                choseBt[0] = Instantiate(choseBtprefab);
                choseBt[0].transform.SetParent(choseBtpos.transform);
                choseBt[0].transform.localPosition = Vector3.zero;
                choseBt[1] = Instantiate(choseBtprefab);
                choseBt[1].transform.SetParent(choseBtpos.transform);
                choseBt[1].transform.localPosition = Vector3.zero;
                choseBt[2] = Instantiate(choseBtprefab);
                choseBt[2].transform.SetParent(choseBtpos.transform);
                choseBt[2].transform.localPosition = Vector3.zero;
                choseBt[3] = Instantiate(choseBtprefab);
                choseBt[3].transform.SetParent(choseBtpos.transform);
                choseBt[3].transform.localPosition = Vector3.zero;
                break;
            case 5:
                choseBt = new GameObject[5];
                choseBt[0] = Instantiate(choseBtprefab);
                choseBt[0].transform.SetParent(choseBtpos.transform);
                choseBt[0].transform.localPosition = Vector3.zero;
                choseBt[1] = Instantiate(choseBtprefab);
                choseBt[1].transform.SetParent(choseBtpos.transform);
                choseBt[1].transform.localPosition = Vector3.zero;
                choseBt[2] = Instantiate(choseBtprefab);
                choseBt[2].transform.SetParent(choseBtpos.transform);
                choseBt[2].transform.localPosition = Vector3.zero;
                choseBt[3] = Instantiate(choseBtprefab);
                choseBt[3].transform.SetParent(choseBtpos.transform);
                choseBt[3].transform.localPosition = Vector3.zero;
                choseBt[4] = Instantiate(choseBtprefab);
                choseBt[4].transform.SetParent(choseBtpos.transform);
                choseBt[4].transform.localPosition = Vector3.zero;
                break;
        }

    }
    //public void addtalkText()
    //{
    //    if (GameDataBassManager.Instance.databass.lovedialogueindex == 1)
    //    {
    //        chose[0].lovessdialogues[0] = "���� �ϰ� ����";
    //        chose[0].lovessdialogues[1] = "����";
    //        chose[1].lovessdialogues[0] = "���� �ϰ� �Ⱦ�";
    //        chose[2].lovessdialogues[0] = "���� �ϰ� �׳� �׷�";
    //    }
    //}


    int numch;
    public void choshesBT(int _dialogueName)
    {
        for (int i = 0; i < choseBt.Length; i++)
        {
            if (i == choseBt.Length)
            {
                break;
            }
            Destroy(choseBt[i].gameObject);
            //choseBt = new GameObject[0];
            //Destroy(choseBt[0].gameObject);
        }
        switch (_dialogueName)
        {
            case 0:
                Debug.Log("0");
                GameDataBassManager.Instance.databass.lovepoint += chosceDatabass.Instance.ChosceDb.chosceTalk[_dialogueName].lovepoint;
                numch = 0;
                break;
            case 1:
                Debug.Log("1");
                GameDataBassManager.Instance.databass.lovepoint += chosceDatabass.Instance.ChosceDb.chosceTalk[_dialogueName].lovepoint;
                numch = 1;
                break;
            case 2:
                Debug.Log("2");
                GameDataBassManager.Instance.databass.lovepoint += chosceDatabass.Instance.ChosceDb.chosceTalk[_dialogueName].lovepoint;
                numch = 2;
                break;
            case 3:
                Debug.Log("3");
                GameDataBassManager.Instance.databass.lovepoint += chosceDatabass.Instance.ChosceDb.chosceTalk[_dialogueName].lovepoint;
                numch = 3;
                break;
        }
        StartCoroutine(dialogueTime());
        
    }

    IEnumerator dialogueTime()
    {
        //lovesdilogue.Instance.NameText.text = chose[GameDataBassManager.Instance.databass.lovedialogueindex].lovesdialogue_name;
        lovesdilogue.Instance.NameText.text = chosceDatabass.Instance.ChosceDb.chosceTalk[numch].lovesdialogue_name;
        lovesdilogue.Instance.sdialogue = chosceDatabass.Instance.ChosceDb.chosceTalk[numch].lovessdialogues[chosceNum];
        yield return new WaitForSeconds(0.5f);
        for (int i = 0; i <= lovesdilogue.Instance.sdialogue.Length; i++)
        {
            lovesdilogue.Instance.dialogueText.text = lovesdilogue.Instance.sdialogue.Substring(0, i);
            yield return new WaitForSeconds(0.1f);
        }
        choseNextbt.SetActive(true);

    }
    public void nextDialogueBt()
    {
        if (lovesdilogue.Instance.nextDialogue + 1 >= chosceDatabass.Instance.ChosceDb.chosceTalk[numch].lovessdialogues.Length)
        {
            Debug.Log("��ȭ ����");
            endDialogue();
            //addChosce += 3;
        }
        else if (lovesdilogue.Instance.nextDialogue < chosceDatabass.Instance.ChosceDb.chosceTalk[numch].lovessdialogues.Length)
        {
            Debug.Log("������ȭ");
            choseNextbt.SetActive(false);
            chosceNum++;
            lovesdilogue.Instance.nextDialogue++;
            StartCoroutine(dialogueTime()); 
            //choshesBT(dialogueName);
            //StartCoroutine(dialogueTime());
        }

    }
    void endDialogue()
    {
        lovesdilogue.Instance.nextDialogue = 0;
        StopCoroutine(dialogueTime());
        chosceNum = 0;
        lovesdilogue.Instance.dialogue_box.SetActive(false);
        choseNextbt.SetActive(false);
        GameDataBassManager.Instance.databass.lovedialogueindex++;
        //_itemindex = 0;
        //popupPanel.SetActive(false);


    }

}
