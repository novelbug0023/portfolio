using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DistanceNpcTalk : MonoBehaviour
{
    public int randomNpcIndex = 0;
    public Image[] NpcImage;
    public Image Npc_Charctor;
    public string NpcName;
    public Text NpcNameText;
    public string[] NpcTalks;
    public string ShowNpcTalk;
    public Text NpcText;
    public GameObject nextBt;
    public int NextNum;
    public enum NpcKinds
    {
        butcher, accessory, restaurant, Pirate, Bandit, amanlyman, anadultwoman, Girl, boy
        //����   //��ű����� //�ָ�����  //����   //����  //���ھ  //���ھ    //�ҳ� //�ҳ�
    }
    public NpcKinds NPC;

    public GameObject distancePanel;
    public GameObject distanceNpcDialoguePanel;

    public void NpcDialogue()
    {
        switch (NPC)
        {
            case NpcKinds.butcher:
                NpcTalks = new string[2];
                NpcName = "����";
                NpcTalks[0] = "��������";
                NpcTalks[1] = "������������";
                break;
            case NpcKinds.accessory:
                NpcName = "��ű� ���ξ��ָӴ�";
                NpcTalks = new string[2];
                NpcTalks[0] = "������������";
                NpcTalks[1] = "������������������";
                break;
            case NpcKinds.restaurant:
                NpcName = "�ָ����ξ��ܸ�";
                NpcTalks = new string[2];
                NpcTalks[0] = "������������";
                NpcTalks[1] = "������������";
                break;
            case NpcKinds.Pirate:
                NpcName = "����";
                NpcTalks = new string[2];
                NpcTalks[0] = "�ˤ���";
                NpcTalks[1] = "������������";
                break;
            case NpcKinds.Bandit:
                NpcName = "����";
                NpcTalks = new string[2];
                NpcTalks[0] = "��������������";
                NpcTalks[1] = "�ˤŤˤ�";
                break;
            case NpcKinds.amanlyman:
                NpcName = "����";
                NpcTalks = new string[2];
                NpcTalks[0] = "��,�Ф̤�,�̤�";
                NpcTalks[1] = "������������";
                break;
            case NpcKinds.anadultwoman:
                NpcName = "����";
                NpcTalks = new string[2];
                NpcTalks[0] = "����������������";
                NpcTalks[1] = "��[��[���Ť���";
                break;
            case NpcKinds.Girl:
                NpcName = "�ҳ�";
                NpcTalks = new string[2];
                NpcTalks[0] = "������������";
                NpcTalks[1] = "��������";
                break;
            case NpcKinds.boy:
                NpcName = "�ҳ�";
                NpcTalks = new string[2];
                NpcTalks[0] = "����";
                NpcTalks[1] = "�ʳʸ�������";
                break;
        }
    }

    public void ShowDistance(string Distancekinds)
    {
        distanceNpcDialoguePanel.SetActive(true);
        switch (Distancekinds)
        {
            case "����":
                Debug.Log(Distancekinds);
                randomNpcIndex = Random.Range(0, 15);
                randomNpc();
                break;
            case "����":
                Debug.Log(Distancekinds);
                randomNpcIndex = Random.Range(16, 20);
                randomNpc();
                break;
            case "��ü":
                Debug.Log(Distancekinds);
                randomNpcIndex = Random.Range(21, 25);
                randomNpc();
                break;
        }
    }
    public void randomNpc()
    {   
        Npc(randomNpcIndex);
        NpcDialogue();
        ShowNpcKind();
    }

    public void ShowNpcKind()
    {
        switch (NPC)
        {
            case NpcKinds.butcher:
                Npc_Charctor = NpcImage[0];
                show_dialogue();
                break;
            case NpcKinds.accessory:
                Npc_Charctor = NpcImage[1];
                show_dialogue();
                break;
            case NpcKinds.restaurant:
                Npc_Charctor = NpcImage[2];
                show_dialogue();
                break;
            case NpcKinds.Pirate:
                Npc_Charctor = NpcImage[3];
                show_dialogue();
                break;
            case NpcKinds.Bandit:
                Npc_Charctor = NpcImage[4];
                show_dialogue();
                break;
            case NpcKinds.amanlyman:
                Npc_Charctor = NpcImage[5];
                show_dialogue();
                break;
            case NpcKinds.anadultwoman:
                Npc_Charctor = NpcImage[6];
                show_dialogue();
                break;
            case NpcKinds.Girl:
                Npc_Charctor = NpcImage[7];
                show_dialogue();
                break;
            case NpcKinds.boy:
                Npc_Charctor = NpcImage[8];
                show_dialogue();
                break;
        }
    }

    public void Npc(int _npc)
    {
        if (randomNpcIndex > 40)
        {
            NPC = NpcKinds.boy;
        }
        else if(randomNpcIndex > 35)
        {
            NPC = NpcKinds.Girl;
        }
        else if (randomNpcIndex > 30)
        {
            NPC = NpcKinds.anadultwoman;
        }
        else if (randomNpcIndex > 25)
        {
            NPC = NpcKinds.amanlyman;
        }
        else if (randomNpcIndex > 20)
        {
            NPC = NpcKinds.Bandit;
        }
        else if (randomNpcIndex > 15)
        {
            NPC = NpcKinds.Pirate;
        }
        else if (randomNpcIndex > 10)
        {
            NPC = NpcKinds.restaurant;
        }
        else if (randomNpcIndex > 5)
        {
            NPC = NpcKinds.accessory;
        }
        else
        {
            NPC = NpcKinds.butcher;
        }
    }

    public void show_dialogue()
    {
        if (NextNum == 0) { NextNum = 0; }
        Debug.Log(NPC);
        Debug.Log(NextNum);
        ShowNpcTalk = NpcTalks[NextNum];
        StartCoroutine(typing());
    }
    IEnumerator typing()
    {
        NpcNameText.text = NpcName;
        yield return new WaitForSeconds(0.5f);
        for (int i = 0; i < ShowNpcTalk.Length; i++)
        {
            NpcText.text = ShowNpcTalk.Substring(0, i);
            yield return new WaitForSeconds(0.1f);
        }
        nextBt.SetActive(true);
    }
    public void NextButton()
    {
        if (NextNum+1 >= NpcTalks.Length)
        {
            Debug.Log("��ȭ ����");
            NextNum = 0;
            endNpcTalk();
        }
        else if(NextNum < NpcTalks.Length)
        {
            NextNum++;
            nextBt.SetActive(false);
            show_dialogue();

        }
    }
    public void endNpcTalk()
    {
        //NextNum = 0;
        GiftItem();
        NpcText.text = "";
        ShowNpcTalk = "";
        NpcTalks = new string[0];
        randomNpcIndex = 0;
        distanceNpcDialoguePanel.SetActive(false);
        distancePanel.SetActive(false);
    }

    void GiftItem()
    {
        switch (NPC)
        {
            case NpcKinds.butcher://����
                int a = Random.Range(0, 1);
                switch (a)
                {
                    case 0:
                        ItemsAddManager.Instance.ItemsList.Add(SystemDataBass.Instance.SYSTEM_DB.meetITEMS[0]);
                        break;
                    case 1:
                        ItemsAddManager.Instance.ItemsList.Add(SystemDataBass.Instance.SYSTEM_DB.meetITEMS[1]);
                        break;
                }
                break;
            case NpcKinds.accessory://��ű���������
                int b = Random.Range(0, 1);
                switch (b)
                {
                    case 0:
                        ItemsAddManager.Instance.ItemsList.Add(SystemDataBass.Instance.SYSTEM_DB.AccessoriesITEMS[0]);
                        break;
                    case 1:
                        ItemsAddManager.Instance.ItemsList.Add(SystemDataBass.Instance.SYSTEM_DB.AccessoriesITEMS[1]);
                        break;
                }
                break;
            case NpcKinds.restaurant://�ָ�����
                int c = Random.Range(0, 1);
                switch (c)
                {
                    case 0:
                        ItemsAddManager.Instance.ItemsList.Add(SystemDataBass.Instance.SYSTEM_DB.FoodITEMS[0]);
                        break;
                    case 1:
                        ItemsAddManager.Instance.ItemsList.Add(SystemDataBass.Instance.SYSTEM_DB.FoodITEMS[1]);
                        break;
                }
                break;
            case NpcKinds.Pirate://����
                if (GameDataBassManager.Instance.databass.money < 1000)
                {
                    GameDataBassManager.Instance.databass.Fatigue += 10;
                }
                else
                {
                    GameDataBassManager.Instance.databass.money =- 1000;
                }
                break;
            case NpcKinds.Bandit://����
                if (GameDataBassManager.Instance.databass.money < 1000)
                {
                    GameDataBassManager.Instance.databass.Fatigue += 10;
                }
                else
                {
                    GameDataBassManager.Instance.databass.money =- 1000;
                }
                break;
            case NpcKinds.amanlyman://���γ���

                break;
            case NpcKinds.anadultwoman://���ο���

                break;
            case NpcKinds.Girl://�ҳ�

                break;
            case NpcKinds.boy://�ҳ�

                break;
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
