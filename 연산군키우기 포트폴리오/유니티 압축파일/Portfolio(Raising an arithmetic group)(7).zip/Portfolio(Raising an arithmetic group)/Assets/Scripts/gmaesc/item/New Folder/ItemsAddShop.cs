using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ItemsAddShop : MonoBehaviour
{

    public void itemsshop()
    {
        for (int i = 0; i < SystemDataBass.Instance.SYSTEM_DB.AccessoriesITEMS.Length; i++)
        {
            if (SystemDataBass.Instance.SYSTEM_DB.AccessoriesITEMS[i].isitem == false)
            {

            }
        }
    }
}
