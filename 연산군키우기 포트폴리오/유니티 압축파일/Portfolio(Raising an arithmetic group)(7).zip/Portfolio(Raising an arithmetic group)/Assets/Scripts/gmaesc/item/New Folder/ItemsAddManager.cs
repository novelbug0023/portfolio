using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ItemsAddManager : MonoBehaviour
{
    #region �̱���
    private static ItemsAddManager instance = null;
    void Awake()
    {
        if (null == instance)
        {
            //�� Ŭ���� �ν��Ͻ��� ź������ �� �������� instance�� ���ӸŴ��� �ν��Ͻ��� ������� �ʴٸ�, �ڽ��� �־��ش�.
            instance = this;

            //�� ��ȯ�� �Ǵ��� �ı����� �ʰ� �Ѵ�.
            //gameObject�����ε� �� ��ũ��Ʈ�� ������Ʈ�μ� �پ��ִ� Hierarchy���� ���ӿ�����Ʈ��� ��������, 
            //���� �򰥸� ������ ���� this�� �ٿ��ֱ⵵ �Ѵ�.
            DontDestroyOnLoad(this.gameObject);
        }
        else
        {
            //���� �� �̵��� �Ǿ��µ� �� ������ Hierarchy�� GameMgr�� ������ ���� �ִ�.
            //�׷� ��쿣 ���� ������ ����ϴ� �ν��Ͻ��� ��� ������ִ� ��찡 ���� �� ����.
            //�׷��� �̹� ���������� instance�� �ν��Ͻ��� �����Ѵٸ� �ڽ�(���ο� ���� GameMgr)�� �������ش�.
            Destroy(this.gameObject);
        }
    }
    public static ItemsAddManager Instance
    {
        get
        {
            if (null == instance)
            {
                return null;
            }
            return instance;
        }
    }
    #endregion

    public List<Items> ItemsList = new List<Items>();
    public List<GameObject> items = new List<GameObject>();
    public GameObject itemsbox;
    public GameObject itemsboxpos;

    public GameObject[] itemobj;
    // Start is called before the first frame update
    void Start()
    {

    }
    public void showItmes()
    {
        
        itemobj = new GameObject[ItemsList.Count];
        for (int i = 0; i < ItemsList.Count; i++)
        {
            
            if (i == ItemsList.Count) { break; }

            //itemobj[i] = Instantiate(itemsbox.gameObject, Vector3.zero, Quaternion.identity, itemsboxpos.transform);
            
            GameObject obj = Instantiate(itemsbox.gameObject, Vector3.zero, Quaternion.identity, itemsboxpos.transform);
            int k = i;

            items.Add(obj);
            obj.GetComponentInChildren<Text>().text = ItemsList[i].itemname;
            obj.AddComponent<itemIndex>().key = k;
            obj.GetComponent<Button>().onClick.AddListener(() => useitem(k));
            //itemobj[k].GetComponentInChildren<Text>().text = ItemsList[i].itemname;
            //itemobj[k].AddComponent<itemIndex>().key = k;
            //itemobj[k].GetComponent<Button>().onClick.AddListener(() => useitem(k));
        }
    }
    void assd(GameObject obj, int k)
    {
        obj.GetComponent<Button>().onClick.AddListener(() => useitem(k));
    }

    public void CloseItems()
    {
        
        for (int i = 0; i < ItemsList.Count; i++)
        {
            if (ItemsList.Count == 0)
            {
                break;
            }
            //Destroy(itemobj[i]);
            Destroy(items[i].gameObject);
        }
        items.Clear();
        //items.Clear();
    }

    //public void cuindex()
    //{
    //        Debug.Log("������");
    //        Destroy(itemobj[0]);
    //        //items.Remove(itemobj[0]);
    //        ItemsList.Remove(GameDataBassManager.Instance.databass.ITEMS[0]);

    //}
    public void useitem(int index)
    {
        for (int i = 0; i < items.Count; i++)
        {
            if (items[i].GetComponent<itemIndex>().key == index)
            {
                if (ItemsList[i].itemindex == 2001)
                {
                    Debug.Log("2001������ ���");
                    Debug.Log("���" + i);
                    int addpoind;
                    addpoind = Random.Range(0, 10);
                    addpoind += ItemsList[i].addstateUp;
                    GameDataBassManager.Instance.databass.decreasing += addpoind;
                    GameDataBassManager.Instance.databass.Charm += addpoind;
                    Destroy(items[i]);
                    items.RemoveAt(i);
                    ItemsList.RemoveAt(i);
                    break;
                }
                if (ItemsList[i].itemindex == 2002)
                {
                    Debug.Log("2002������ ���");
                    Debug.Log("���" + index);
                    int addpoind;
                    addpoind = Random.Range(0, 10);
                    addpoind += ItemsList[i].addstateUp;
                    GameDataBassManager.Instance.databass.decreasing += addpoind;
                    GameDataBassManager.Instance.databass.Politics += addpoind;
                    Destroy(items[i]);
                    items.RemoveAt(i);
                    ItemsList.RemoveAt(i);
                    break;
                }
                if (ItemsList[i].itemindex == 2003)
                {
                    Debug.Log("2003������ ���");
                    Debug.Log("���" + i);
                    int addpoind;
                    addpoind = Random.Range(0, 10);
                    addpoind += ItemsList[i].addstateUp;
                    GameDataBassManager.Instance.databass.decreasing += addpoind;
                    GameDataBassManager.Instance.databass.Charm += addpoind;
                    Destroy(items[i]);
                    items.RemoveAt(i);
                    ItemsList.RemoveAt(i);
                    break;
                }
                if (ItemsList[i].itemindex == 2004)
                {
                    Debug.Log("2004������ ���");
                    Debug.Log("���" + i);
                    int addpoind;
                    addpoind = Random.Range(0, 10);
                    addpoind += ItemsList[i].addstateUp;
                    GameDataBassManager.Instance.databass.decreasing += addpoind;
                    GameDataBassManager.Instance.databass.Charm += addpoind;
                    Destroy(items[i]);
                    items.RemoveAt(i);
                    ItemsList.RemoveAt(i);
                    break;
                }
                if (ItemsList[i].itemindex == 2005)
                {
                    Debug.Log("2005������ ���");
                    Debug.Log("���" + i);
                    int addpoind;
                    addpoind = Random.Range(0, 10);
                    addpoind += ItemsList[i].addstateUp;
                    GameDataBassManager.Instance.databass.Fatigue -= addpoind;
                    
                    Destroy(items[i]);
                    items.RemoveAt(i);
                    ItemsList.RemoveAt(i);
                    break;
                }
                if (ItemsList[i].itemindex == 2006)
                {
                    Debug.Log("2006������ ���");
                    Debug.Log("���" + i);
                    int addpoind;
                    addpoind = Random.Range(0, 10);
                    addpoind += ItemsList[i].addstateUp;
                    GameDataBassManager.Instance.databass.Fatigue -= addpoind;
                    Destroy(items[i]);
                    items.RemoveAt(i);
                    ItemsList.RemoveAt(i);
                    break;
                }
                if (ItemsList[i].itemindex == 2007)
                {
                    Debug.Log("2007������ ���");
                    Debug.Log("���" + i);
                    int addpoind;
                    addpoind = Random.Range(0, 10);
                    addpoind += ItemsList[i].addstateUp;
                    GameDataBassManager.Instance.databass.decreasing += addpoind;
                    GameDataBassManager.Instance.databass.Charm += addpoind;
                    Destroy(items[i]);
                    items.RemoveAt(i);
                    ItemsList.RemoveAt(i);
                    break;
                }
                if (ItemsList[i].itemindex == 2008)
                {
                    Debug.Log("2008������ ���");
                    Debug.Log("���" + i);
                    int addpoind;
                    addpoind = Random.Range(0, 10);
                    addpoind += ItemsList[i].addstateUp;
                    GameDataBassManager.Instance.databass.decreasing += addpoind;
                    GameDataBassManager.Instance.databass.Charm += addpoind;
                    Destroy(items[i]);
                    items.RemoveAt(i);
                    ItemsList.RemoveAt(i);
                    break;
                }
                if (ItemsList[i].itemindex == 2009)
                {
                    Debug.Log("2009������ ���");
                    Debug.Log("���" + i);
                    int addpoind;
                    addpoind = Random.Range(0, 10);
                    addpoind += ItemsList[i].addstateUp;
                    GameDataBassManager.Instance.databass.decreasing += addpoind;
                    GameDataBassManager.Instance.databass.Charm += addpoind;
                    Destroy(items[i]);
                    items.RemoveAt(i);
                    ItemsList.RemoveAt(i);
                    break;
                }
                //Debug.Log("���" + index);
                //Destroy(items[i]);
                //items.RemoveAt(i);
                //ItemsList.RemoveAt(i);

                //break;
            }
        }
        
    }
    //public void useitems(int _index)
    //{
    //    for (int i = 0; i < ItemsList.Count; i++)
    //    {
    //        if (items[i].GetComponent<itemIndex>().key == _index)
    //        {
    //            if (ItemsList[i].itemindex == 2001)
    //            {
    //                Debug.Log("2001������ ���");
    //            }
    //            if (ItemsList[i].itemindex == 2002)
    //            {
    //                Debug.Log("2002������ ���");
    //            }
    //            if (ItemsList[i].itemindex == 2003)
    //            {
    //                Debug.Log("2003������ ���");
    //            }
    //            if (ItemsList[i].itemindex == 2004)
    //            {
    //                Debug.Log("2004������ ���");
    //            }
    //            if (ItemsList[i].itemindex == 2005)
    //            {
    //                Debug.Log("2005������ ���");
    //            }
    //            if (ItemsList[i].itemindex == 2006)
    //            {
    //                Debug.Log("2006������ ���");
    //            }
    //            if (ItemsList[i].itemindex == 2007)
    //            {
    //                Debug.Log("2007������ ���");
    //            }
    //            if (ItemsList[i].itemindex == 2008)
    //            {
    //                Debug.Log("2008������ ���");
    //            }
    //        }
    //    }
    //}
    // Update is called once per frame
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.A))
        {
            Debug.Log("addItems0");
            ItemsList.Add(SystemDataBass.Instance.SYSTEM_DB.AccessoriesITEMS[0]);

        }
        if (Input.GetKeyDown(KeyCode.Q))
        {
            Debug.Log("addItems1");
            ItemsList.Add(SystemDataBass.Instance.SYSTEM_DB.AccessoriesITEMS[1]);

        }
        if (Input.GetKeyDown(KeyCode.S))
        {
            if (items.Count > 0)
            {
                Debug.Log("CancelItems");
                ItemsList.Remove(SystemDataBass.Instance.SYSTEM_DB.AccessoriesITEMS[0]);
                Destroy(items[0]);
                items.Remove(items[0]);
            }
        }
    }
}

