using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "ItmesData", menuName = "Scriptabl eObject/items Data", order = int.MaxValue)]
public class Items : ScriptableObject
{
    public int itemindex;
    public string itemname;
    public string itemexplanation;
    public bool isitem = false;
    public int addstateUp = 0;
    public Sprite skinitem;
}
