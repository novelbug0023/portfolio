using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class itmeAdd : MonoBehaviour
{
    public GameObject popupbutton;
    public GameObject popupPanel;
    public GameObject[] popup;
    public GameObject popuppos;
    public Text popupText;
    int _itemindex;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    public void addItem(int itemindex)
    {
        if (itemManager.Instance.itmedb[itemindex].isitem == false)
        {
            if (GameDataBassManager.Instance.databass.money >= 1000)
            {
                popupPanel.SetActive(true);
                popupText.text = itemManager.Instance.itmedb[itemindex].itemname + "�� ���� �Ͻðڽ��ϱ�?";
                _itemindex = itemindex;
                popup[0] = Instantiate(popupbutton);
                popup[0].transform.SetParent(popuppos.transform);
                popup[0].transform.localPosition = Vector3.zero;
                popup[1] = Instantiate(popupbutton);
                popup[1].transform.SetParent(popuppos.transform);
                popup[1].transform.localPosition = Vector3.zero;
                popup[0].GetComponent<Button>().onClick.AddListener(additems);
                popup[0].GetComponentInChildren<Text>().text = "����";
                popup[1].GetComponent<Button>().onClick.AddListener(closePopup);
                popup[1].GetComponentInChildren<Text>().text = "���";


            }
            else
            {
                popupPanel.SetActive(true);
                popup[0] = Instantiate(popupbutton);
                popup[0].transform.SetParent(popuppos.transform);
                popup[0].transform.localPosition = Vector3.zero;
                popup[0].GetComponent<Button>().onClick.AddListener(closePopup);
                popupText.text = "���� �����մϴ�";
                Debug.Log("���� �����մϴ�");
            }
        }
        else
        {
            GameDataBassManager.Instance.databass.charture.sprite = itemManager.Instance.itmedb[itemindex].skinitem;
        }
    }
    public void closePopup()
    {
        _itemindex = 0;
        popupPanel.SetActive(false);
        for (int i = 0; i < popup.Length; i++)
        {
            if (i == popup.Length)
            {
                break;
            }
            Destroy(popup[i].gameObject);
        }
       
    }
    public void additems()
    {
        GameDataBassManager.Instance.databass.money -= 1000;
        itemManager.Instance.itmedb[_itemindex].isitem = true;
        closePopup();

    }
}
