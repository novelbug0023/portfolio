using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GamebtManager : MonoBehaviour
{
    SchedulesystemManager schdulesManager;
    public GameObject clerender;
    public GameObject state;
    bool isState;
    public GameObject Closet;
    bool isCloset;
    public GameObject dilogues;
    public GameObject endingdataPanel;

    public bool pageb;
    public int pageindex;
    public Text pageindex_t;
    public GameObject[] page;
    // Start is called before the first frame update
    void Start()
    {
        schdulesManager = GameObject.Find("schduleManager").GetComponent<SchedulesystemManager>();
    }

    // Update is called once per frame
    void Update()
    {
        if (pageb)
        {
            if (pageindex == 0)
            {
                page[--pageindex].SetActive(true);
                page[pageindex].SetActive(true);
            }
            if (pageindex == 1)
            {
                page[++pageindex].SetActive(true);
                page[pageindex].SetActive(true);
            }
        }
    }
    public void bt(string bt)
    {
        switch (bt)
        {
            case "����":
                clerender.SetActive(true);
                schdulesManager.StartCalendar();
                
                break;
            case "�����ݱ�":
                clerender.SetActive(false);
                schdulesManager.endCalendar();
                //schdulesManager.StartCalendar();

                break;
            case "����":
                if (isState)
                {
                    state.SetActive(false);
                    isState = false;
                }
                else
                {
                    state.SetActive(true);
                    Closet.SetActive(false);
                    
                    isState = true;
                }
                break;
            case "����":
                if (isCloset)
                {
                    Closet.SetActive(false);
                    isCloset = false;
                }
                else
                {
                    Closet.SetActive(true);
                    state.SetActive(false);
                    
                    isCloset = true;
                }
                break;
            case "��ȭâ":
                    lovesTalk();
                break;
            case "����������":
                pageb = true;
                endingdataPanel.SetActive(true);
                break;
            case "���������ʹݱ�":
                pageb = false;
                endingdataPanel.SetActive(false);
                break;
            case "������ �ʱ�ȭ":
                GameDataBassManager.Instance.databass.ps = 10;
                GameDataBassManager.Instance.databass.tlp = 10;
                GameDataBassManager.Instance.databass.gorce = 10;
                GameDataBassManager.Instance.databass.decreasing = 10;
                GameDataBassManager.Instance.databass.Politics = 10;
                GameDataBassManager.Instance.databass.Charm = 10;
                GameDataBassManager.Instance.databass.Karma = 10;
                GameDataBassManager.Instance.databass.Fatigue = 10;
                GameDataBassManager.Instance.databass.money = 1000;
                GameDataBassManager.Instance.databass.firstGame = true;
                dialogueManager.Instance.Start();
                dialogueManager.Instance.dialogueindex = 0;
                GameDataBassManager.Instance.databass.year = 1483;
                GameDataBassManager.Instance.databass.month = 11;
                GameDataBassManager.Instance.databass.day = 23;
                GameDataBassManager.Instance.databass.ending01 = false;
                GameDataBassManager.Instance.databass.ending02 = false;
                for (int i = 1; i < GameDataBassManager.Instance.databass.items.Length; i++)
                {
                    if (GameDataBassManager.Instance.databass.items.Length < i)
                    {
                        break;
                    }
                    GameDataBassManager.Instance.databass.items[i].isitem = false;
                    GameDataBassManager.Instance.databass.charture.sprite = GameDataBassManager.Instance.databass.items[0].skinitem;
                }
                lovesdilogue.Instance.dialogueindex = 0;
                choshecDialogue.Instance.dialogueName = 0;
                GameDataBassManager.Instance.JsonSaveData();
                break;
            case "������������":
                pageindex++;
                break;
            case "���������� �ٿ�":
                pageindex--;
                break;
            case "���� ����":
                GameDataBassManager.Instance.JsonSaveData();
                ExitGame();
                
                break;

        }
    }
    void lovesTalk()
    {
        itmeAdd.Instance.popupPanel.SetActive(true);
        itmeAdd.Instance.popup[0] = Instantiate(itmeAdd.Instance.popupbutton);
        itmeAdd.Instance.popup[0].transform.SetParent(itmeAdd.Instance.popuppos.transform);
        itmeAdd.Instance.popup[0].transform.localPosition = Vector3.zero;
        itmeAdd.Instance.popup[1] = Instantiate(itmeAdd.Instance.popupbutton);
        itmeAdd.Instance.popup[1].transform.SetParent(itmeAdd.Instance.popuppos.transform);
        itmeAdd.Instance.popup[1].transform.localPosition = Vector3.zero;
        itmeAdd.Instance.popup[0].GetComponent<Button>().onClick.AddListener(addtalk);
        itmeAdd.Instance.popup[0].GetComponentInChildren<Text>().text = "��ȭ�ϱ�";
        itmeAdd.Instance.popup[1].GetComponent<Button>().onClick.AddListener(closetalk);
        itmeAdd.Instance.popup[1].GetComponentInChildren<Text>().text = "���";
        itmeAdd.Instance.popupText.text = "��ȭ�� �Ͻðڽ��ϱ�?";

    }
    public void addtalk()
    {
        itmeAdd.Instance.popupPanel.SetActive(false);
        lovesdilogue.Instance.dialogue();
        dilogues.SetActive(true);
        for (int i = 0; i < itmeAdd.Instance.popup.Length; i++)
        {
            if (i == itmeAdd.Instance.popup.Length)
            {
                break;
            }
            Destroy(itmeAdd.Instance.popup[i].gameObject);
        }
    }
    public void closetalk()
    {
        itmeAdd.Instance.popupPanel.SetActive(false);
        for (int i = 0; i < itmeAdd.Instance.popup.Length; i++)
        {
            if (i == itmeAdd.Instance.popup.Length)
            {
                break;
            }
            Destroy(itmeAdd.Instance.popup[i].gameObject);
        }

    }

    public void ExitGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit() // ���ø����̼� ����
#endif
    }
}
