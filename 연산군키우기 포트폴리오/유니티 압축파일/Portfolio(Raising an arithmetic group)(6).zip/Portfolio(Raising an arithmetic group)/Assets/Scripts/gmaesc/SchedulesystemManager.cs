using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SchedulesystemManager : MonoBehaviour
{
    #region �̱���
    private static SchedulesystemManager instance = null;
    void Awake()
    {
        if (null == instance)
        {
            //�� Ŭ���� �ν��Ͻ��� ź������ �� �������� instance�� ���ӸŴ��� �ν��Ͻ��� ������� �ʴٸ�, �ڽ��� �־��ش�.
            instance = this;

            //�� ��ȯ�� �Ǵ��� �ı����� �ʰ� �Ѵ�.
            //gameObject�����ε� �� ��ũ��Ʈ�� ������Ʈ�μ� �پ��ִ� Hierarchy���� ���ӿ�����Ʈ��� ��������, 
            //���� �򰥸� ������ ���� this�� �ٿ��ֱ⵵ �Ѵ�.
            DontDestroyOnLoad(this.gameObject);
        }
        else
        {
            //���� �� �̵��� �Ǿ��µ� �� ������ Hierarchy�� GameMgr�� ������ ���� �ִ�.
            //�׷� ��쿣 ���� ������ ����ϴ� �ν��Ͻ��� ��� ������ִ� ��찡 ���� �� ����.
            //�׷��� �̹� ���������� instance�� �ν��Ͻ��� �����Ѵٸ� �ڽ�(���ο� ���� GameMgr)�� �������ش�.
            Destroy(this.gameObject);
        }
    }
    public static SchedulesystemManager Instance
    {
        get
        {
            if (null == instance)
            {
                return null;
            }
            return instance;
        }
    }
    #endregion
    ScheduleBtManager schedulebt;
    GameDataBassManager db;

    public string schdule;
    public int schdulenum;
    public string[] schdules;

    int Calendar = 365;

    int isschedules = 0;
    int schdulesDay = 0;
    //boo isTime = 0;

    public List<string> schdulesList = new List<string>();
    public GameObject schdulesboxs;
    public Image imageSchdules;
    public GameObject schdulesboxsnull;
    public GameObject Calendars;
    public GameObject[] schdulesLayers;
    public GameObject[] NoneLayers;
    public GameObject SCHDULEPENAL;
    List<GameObject> schdulesbox = new List<GameObject>();


    public GameObject scdulesPanal;

    [Header("������Ʈ �������ͽ�")]
    //public Image ps
    public Image psp_i; //ü��
    public Image tlpp_i; //���
    public Image gorcep_i; //����
    public Image decreasingp_i; //����
    public Image Politicsp_i; //��ġ
    public Image Charmp_i; //�ŷ�
    public Image Karmap_i; //����
    public Image Fatiguep_i; //�Ƿ�   

    public Text psp_t; //ü��
    public Text tlpp_t; //���
    public Text gorcep_t; //����
    public Text decreasingp_t; //����
    public Text Politicsp_t; //��ġ
    public Text Charmp_t; //�ŷ�
    public Text Karmap_t; //����
    public Text Fatiguep_t; //�Ƿ�   
    //=================================================
    //bool isleapyeaar;

    // Start is called before the first frame update
    void Start()
    {
        schedulebt = GameObject.Find("schdulebt").GetComponent<ScheduleBtManager>();
        db = GameObject.Find("databass").GetComponent<GameDataBassManager>();
        //////////////////////////
        psp = 0; //ü��
        tlpp = 0; //���
        gorcep = 0; //����
        decreasingp = 0; //����
        Politicsp = 0; //��ġ
        Charmp = 0; //�ŷ�
        Karmap = 0; //����
        Fatiguep = 0; //�Ƿ�    

        MAXpsp = 1000; //ü��
        MAXtlpp = 1000; //���
        MAXgorcep = 1000; //����
        MAXdecreasingp = 1000; //����
        MAXPoliticsp = 1000; //��ġ
        MAXCharmp = 1000; //�ŷ�
        MAXKarmap = 1000; //����
        MAXFatiguep = 1000; //�Ƿ�    

        psp_i.fillAmount = (float)psp / (float)MAXpsp;
        tlpp_i.fillAmount = (float)tlpp / (float)MAXtlpp;
        gorcep_i.fillAmount = (float)gorcep / (float)MAXgorcep;
        decreasingp_i.fillAmount = (float)decreasingp / (float)MAXdecreasingp;
        Politicsp_i.fillAmount = (float)Politicsp / (float)MAXPoliticsp;
        Charmp_i.fillAmount = (float)Charmp / (float)MAXCharmp;
        Fatiguep_i.fillAmount = (float)Fatiguep / (float)MAXFatiguep;
        psp_t.text = psp.ToString(); //ü��
        tlpp_t.text = tlpp.ToString(); //���
        gorcep_t.text = gorcep.ToString(); //����
        decreasingp_t.text = decreasingp.ToString(); //����
        Politicsp_t.text = Politicsp.ToString(); //��ġ
        Charmp_t.text = Charmp.ToString(); //�ŷ�
        Fatiguep_t.text = Fatiguep.ToString(); //�Ƿ�   

    }
    public void StartCalendar()
    {
        isleapyeaar(db.databass.year);
        lastDay(db.databass.year, db.databass.month);
        totalDay(db.databass.year, db.databass.month, db.databass.day);
        wickday(db.databass.year, db.databass.month, db.databass.day);
        //Debug.Log(db.year+"��"+db.month+"��\n");
        //Debug.Log("��    ��   ȭ   ��   ��   ��   ��\n");
        for (int i = 0; i < wickday(db.databass.year, db.databass.month, 1); i++)
        {
            if (i == wickday(db.databass.year, db.databass.month, 1))
            {
                break;
            }
            //Debug.Log("");

            //if (schdulesLayers[i] != null) { DestroyImmediate(schdulesLayers[i]); }
            NoneLayers[i] = Instantiate(schdulesboxsnull);
            NoneLayers[i].transform.SetParent(Calendars.transform);
            NoneLayers[i].transform.localPosition = Vector3.zero;

            //Calendars.transform.parent = schdulesLayers[i].transform.position;
            //obj.transform.parent = FindObjectOfType<Canvas>().transform;
        }
        for (int i = 0; i < lastDay(db.databass.year, db.databass.month) + 1; i++)
        {
            if (i == schdulesLayers.Length)
            {
                break;
            }

            schdulesLayers[i] = Instantiate(schdulesboxs);
            //Calendars.transform.position = schdulesLayers[i].transform.position;
            schdulesLayers[i].transform.SetParent(Calendars.transform);
            schdulesLayers[i].transform.localPosition = Vector3.zero;
            schdulesLayers[i].GetComponentInChildren<Text>().text = (1 + i).ToString();
            Debug.Log(i);
            if (wickday(db.databass.year, db.databass.month, i) == 6 && lastDay(db.databass.year, db.databass.month) != i)
            {

                Debug.Log("\n");
            }
        }
    }
    public void endCalendar()
    {
        for (int i = 0; i < wickday(db.databass.year, db.databass.month, 1); i++)
        {
            if (i == wickday(db.databass.year, db.databass.month, 1))
            {
                break;
            }
            Destroy(NoneLayers[i]);
        }
        for (int i = 0; i < lastDay(db.databass.year, db.databass.month) + 1; i++)
        {
            if (i == schdulesLayers.Length)
            {
                break;
            }
            if (schdulesLayers.Length >= 29)
            {
                Destroy(schdulesLayers[29]);
                Destroy(schdulesLayers[30]);
                //Destroy(schdulesLayers[31]);
            }
            Destroy(schdulesLayers[i]);
        }
    }

    #region ����޷�
    public bool isleapyeaar(int year)
    {
        //year = db.year;
        return db.databass.year % 4 == 0 && db.databass.year % 100 != 0 || db.databass.year % 400 == 0;
    }
    public int lastDay(int year, int month)
    {
        //month = db.month;
        int[] m = new int[12] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        m[1] = isleapyeaar(year) ? 29 : 28;
        return m[month - 1];
    }
    public int totalDay(int year, int month, int day)
    {
        int total = (year - 1) * 365 + (year - 1) / 4 - (year - 1) / 100 + (year - 1) / 400;
        for (int i = 1; i < month; i++)
        {
            total += lastDay(year, i);
        }
        return total + day;
    }
    public int wickday(int year, int month, int day)
    {
        return totalDay(year, month, day) % 7;
    }
    #endregion

    // Update is called once per frame
    void Update()
    {
        StartCoroutine(Fatiguepchake());
        #region ����
        if (!db.databass.ending01)
        {
            ENDINGS();
        }
        #endregion
    }
    public void ENDINGS()
    {
        if (db.databass.Fatigue == 1000 && db.databass.Karma == 500)
        {
            db.databass.ending01 = true;
            EndingManager.Instance.endings();
        }
    }

    IEnumerator Fatiguepchake()
    {
        #region ��ġ ����ȭ
        //if (db.databass.month >= 13)
        //{
        //    db.databass.month = 1;
        //    db.databass.year++;
        //}
        if (db.databass.Fatigue < 0)
        {
            db.databass.Fatigue = 0;
        }
        if (db.databass.ps > 1000)
        {
            db.databass.ps = 1000;
        }
        if (db.databass.tlp > 1000)
        {
            db.databass.tlp = 1000;
        }
        if (db.databass.gorce > 1000)
        {
            db.databass.gorce = 1000;
        }
        if (db.databass.decreasing > 1000)
        {
            db.databass.decreasing = 1000;
        }
        if (db.databass.Politics > 1000)
        {
            db.databass.Politics = 1000;
        }
        if (db.databass.Charm > 1000)
        {
            db.databass.Charm = 1000;
        }
        if (db.databass.Karma > 1000)
        {
            db.databass.Karma = 1000;
        }
        if (db.databass.Fatigue > 1000)
        {
            db.databass.Fatigue = 1000;
        }
        #endregion
        yield return null;
    }
    public int statck = 0;
    public int ScCount;
    public void addSchdules()
    {
        for (int i = 0; i < 8; i++)
        {
            if (i == 8)
            {
                break;
            }
            if (schdulesList.Count > 31)
            {
                return;
            }
            schdulesList.Add(schdules[i]);
        }

        for (int j = statck * 8; j < (8 * statck) + 8; j++)
        {
            if (j == 31)
            {
                break;
            }
            for (int i = 0; i < 8; i++)
            {
                switch (schdules[i])
                {
                    case "��������":
                        schdulesLayers[j].GetComponent<Image>().color = Color.red;


                        //schdulesDay = 0;
                        break;
                    case "��������":
                        schdulesLayers[j].GetComponent<Image>().color = Color.blue;

                        //schdulesDay = 0;
                        break;
                    case "������3":
                        schdulesLayers[j].GetComponent<Image>().color = Color.green;

                        //schdulesDay = 0;
                        break;
                    case "�����н�":
                        schdulesLayers[j].GetComponent<Image>().color = Color.grey;


                        //schdulesDay = 0;
                        break;
                    case "�����н�":
                        schdulesLayers[j].GetComponent<Image>().color = Color.black;


                        //schdulesDay = 0;
                        break;
                    case "��ġ�� �н�":
                        schdulesLayers[j].GetComponent<Image>().color = Color.blue + Color.red;

                        //schdulesDay = 0;
                        break;
                    case "�ÿ��� �߱���":
                        schdulesLayers[j].GetComponent<Image>().color = Color.cyan;


                        //schdulesDay = 0;
                        break;
                    case "�ù����� ���� ������":
                        schdulesLayers[j].GetComponent<Image>().color = Color.white;

                        //schdulesDay = 0;
                        break;
                }
            }
        }
        statck++;
    }

    public void scheduleTimestart()
    {
        if (schdulesList.Count < 28)
        {
            Debug.Log("������ �� ���� �ʾҽ��ϴ�.");
        }
        else
        {
            scdulesPanal.SetActive(true);
            isschedules = 1;
            StartCoroutine(scheduleTime());
        }
    }
    #region ������ ���� eq
    float eq1 = 0;
    float eq1_2 = 0;
    float eq1_3 = 0;


    int psp = 0; //ü��
    int tlpp = 0; //���
    int gorcep = 0; //����
    int decreasingp = 0; //����
    int Politicsp = 0; //��ġ
    int Charmp = 0; //�ŷ�
    int Karmap = 0; //����
    int Fatiguep = 0; //�Ƿ� 

    int MAXpsp = 1000; //ü��
    int MAXtlpp = 1000; //���
    int MAXgorcep = 1000; //����
    int MAXdecreasingp = 1000; //����
    int MAXPoliticsp = 1000; //��ġ
    int MAXCharmp = 1000; //�ŷ�
    int MAXKarmap = 1000; //����
    int MAXFatiguep = 1000; //�Ƿ�    
    #endregion

    private void mo()
    {
        if (db.databass.Fatigue > 600)
        {
            switch (schdule)
            {
                case "��������":

                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;


                    //schdulesDay = 0;
                    break;
                case "��������":

                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;

                    break;
                case "������3":

                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;

                    break;
                case "�����н�":

                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;
                    //schdulesDay = 0;
                    break;
                case "�����н�":

                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;
                    //schdulesDay = 0;
                    break;
                case "��ġ�� �н�":

                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;
                    //schdulesDay = 0;
                    break;
                case "�ÿ��� �߱���":
                    eq1 = Random.Range(0.0f, 1.5f);
                    Fatiguep += (int)eq1;
                    db.databass.Fatigue -= Fatiguep;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;
                    //schdulesDay = 0;
                    break;
                case "�ù����� ���� ������":
                    eq1 = Random.Range(0.0f, 1.5f);
                    Fatiguep += (int)eq1;
                    db.databass.Fatigue -= Fatiguep;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;
                    //schdulesDay = 0;
                    break;
            }
        }
        if (db.databass.Fatigue > 300)
        {
            switch (schdule)
            {
                case "��������":
                    eq1 = Random.Range(0.0f, 1.5f);
                    eq1_2 = Random.Range(0.0f, 1.5f);
                    eq1_3 = Random.Range(1.0f, 5.0f);
                    psp += (int)eq1;
                    gorcep += (int)eq1_2;
                    Fatiguep += (int)eq1_3;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;


                    //schdulesDay = 0;
                    break;
                case "��������":
                    eq1 = Random.Range(0.0f, 1.5f);
                    eq1_2 = Random.Range(0.0f, 1.5f);
                    eq1_3 = Random.Range(1.0f, 5.0f);
                    psp += (int)eq1;
                    gorcep += (int)eq1_2;
                    Fatiguep += (int)eq1_3;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;

                    break;
                case "������3":
                    eq1 = Random.Range(0.0f, 1.5f);
                    eq1_2 = Random.Range(0.0f, 1.5f);
                    eq1_3 = Random.Range(1.0f, 5.0f);
                    psp += (int)eq1;
                    gorcep += (int)eq1_2;
                    Fatiguep += (int)eq1_3;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;

                    break;
                case "�����н�":
                    eq1 = Random.Range(0.0f, 1.5f);
                    eq1_2 = Random.Range(1.0f, 5.0f);
                    decreasingp += (int)eq1;
                    Fatiguep += (int)eq1_2;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;
                    //schdulesDay = 0;
                    break;
                case "�����н�":
                    eq1 = Random.Range(0.0f, 1.5f);
                    eq1_2 = Random.Range(1.0f, 5.0f);
                    Charmp += (int)eq1;
                    Fatiguep += (int)eq1_2;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;
                    //schdulesDay = 0;
                    break;
                case "��ġ�� �н�":
                    eq1 = Random.Range(0.0f, 1.5f);
                    eq1_2 = Random.Range(0.0f, 1.5f);
                    eq1_3 = Random.Range(1.0f, 5.0f);
                    Politicsp += (int)eq1;
                    decreasingp += (int)eq1_2;
                    Fatiguep += (int)eq1_3;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;
                    //schdulesDay = 0;
                    break;
                case "�ÿ��� �߱���":
                    eq1 = Random.Range(1.0f, 2.0f);
                    Fatiguep += (int)eq1;
                    db.databass.Fatigue -= Fatiguep;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;
                    //schdulesDay = 0;
                    break;
                case "�ù����� ���� ������":
                    eq1 = Random.Range(1.0f, 2.0f);
                    Fatiguep += (int)eq1;
                    db.databass.Fatigue -= Fatiguep;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;
                    //schdulesDay = 0;
                    break;
            }
        }
        else
        {
            switch (schdule)
            {
                case "��������":
                    eq1 = Random.Range(1.0f, 2.0f);
                    eq1_2 = Random.Range(1.0f, 2.0f);
                    eq1_3 = Random.Range(1.0f, 5.0f);
                    psp += (int)eq1;
                    gorcep += (int)eq1_2;
                    Fatiguep += (int)eq1_3;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;


                    //schdulesDay = 0;
                    break;
                case "��������":
                    eq1 = Random.Range(1.0f, 2.0f);
                    eq1_2 = Random.Range(1.0f, 2.0f);
                    eq1_3 = Random.Range(1.0f, 5.0f);
                    psp += (int)eq1;
                    gorcep += (int)eq1_2;
                    Fatiguep += (int)eq1_3;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;

                    break;
                case "������3":
                    eq1 = Random.Range(1.0f, 2.0f);
                    eq1_2 = Random.Range(1.0f, 2.0f);
                    eq1_3 = Random.Range(1.0f, 5.0f);
                    psp += (int)eq1;
                    gorcep += (int)eq1_2;
                    Fatiguep += (int)eq1_3;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;

                    break;
                case "�����н�":
                    eq1 = Random.Range(1.0f, 2.0f);
                    eq1_2 = Random.Range(1.0f, 5.0f);
                    decreasingp += (int)eq1;
                    Fatiguep += (int)eq1_2;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;
                    //schdulesDay = 0;
                    break;
                case "�����н�":
                    eq1 = Random.Range(1.0f, 2.0f);
                    eq1_2 = Random.Range(1.0f, 5.0f);
                    Charmp += (int)eq1;
                    Fatiguep += (int)eq1_2;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;
                    //schdulesDay = 0;
                    break;
                case "��ġ�� �н�":
                    eq1 = Random.Range(1.0f, 2.0f);
                    eq1_2 = Random.Range(1.0f, 2.0f);
                    eq1_3 = Random.Range(1.0f, 5.0f);
                    Politicsp += (int)eq1;
                    decreasingp += (int)eq1_2;
                    Fatiguep += (int)eq1_3;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;
                    //schdulesDay = 0;
                    break;
                case "�ÿ��� �߱���":
                    eq1 = Random.Range(1.0f, 2.0f);
                    Fatiguep += (int)eq1;
                    db.databass.Fatigue -= Fatiguep;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;
                    //schdulesDay = 0;
                    break;
                case "�ù����� ���� ������":
                    eq1 = Random.Range(1.0f, 2.0f);
                    Fatiguep += (int)eq1;
                    db.databass.Fatigue -= Fatiguep;
                    eq1 = 0;
                    eq1_2 = 0;
                    eq1_3 = 0;
                    //schdulesDay = 0;
                    break;
            }
        }

    }
    public void b()
    {
        if (schdulesList.Count <= db.databass.day) { return; }
        switch (schdulesList[db.databass.day])
        {
            case "��������":
                schdule = schdulesList[db.databass.day];
                imageSchdules.GetComponent<Image>().color = Color.red;
                //schdulesDay = 0;
                break;
            case "��������":
                schdule = schdulesList[db.databass.day];
                imageSchdules.GetComponent<Image>().color = Color.blue;

                break;
            case "������3":
                schdule = schdulesList[db.databass.day];
                imageSchdules.GetComponent<Image>().color = Color.green;

                break;
            case "�����н�":
                schdule = schdulesList[db.databass.day];
                imageSchdules.GetComponent<Image>().color = Color.grey;

                //schdulesDay = 0;
                break;
            case "�����н�":
                schdule = schdulesList[db.databass.day];
                imageSchdules.GetComponent<Image>().color = Color.black;

                //schdulesDay = 0;
                break;
            case "��ġ�� �н�":
                schdule = schdulesList[db.databass.day];
                imageSchdules.GetComponent<Image>().color = Color.blue + Color.red;
                //schdulesDay = 0;
                break;
            case "�ÿ��� �߱���":
                schdule = schdulesList[db.databass.day];
                imageSchdules.GetComponent<Image>().color = Color.cyan;
                //schdulesDay = 0;
                break;
            case "�ù����� ���� ������":
                schdule = schdulesList[db.databass.day];
                imageSchdules.GetComponent<Image>().color = Color.white;
                //schdulesDay = 0;
                break;
        }
        //monthkins();
    }

    IEnumerator scheduleTime()
    {
        for (int i = 0; i < 31; i++)
        {
            yield return new WaitForSeconds(1f);
            //s();
            b();
            //monthkins();
            db.databass.day++;
            mo();
            monthkins();

            if (isschedules == 1)
            {
                i = 0;
            }
            else { break; }

        }
    }
    public void yerss()
    {
        resetMonth();
        Sccalculate();

    }
    #region ���� �����ͺ��̽�
    public void monthkins()
    {
        if (db.databass.month == 1)
        {
            if (db.databass.day > 31)
            {
                yerss();
            }
        }
        if (db.databass.month == 2)
        {
            if (db.databass.day > 28)
            {
                yerss();
            }
        }
        if (db.databass.month == 3)
        {
            if (db.databass.day > 31)
            {
                yerss();
            }
        }
        if (db.databass.month == 4)
        {
            if (db.databass.day > 30)
            {
                yerss();
            }
        }
        if (db.databass.month == 5)
        {
            if (db.databass.day > 31)
            {
                yerss();
            }
        }
        if (db.databass.month == 6)
        {
            if (db.databass.day > 30)
            {
                yerss();
            }
        }
        if (db.databass.month == 7)
        {
            if (db.databass.day > 31)
            {
                yerss();
            }
        }
        if (db.databass.month == 8)
        {
            if (db.databass.day > 31)
            {
                yerss();
            }
        }
        if (db.databass.month == 9)
        {
            if (db.databass.day > 30)
            {
                yerss();
            }
        }
        if (db.databass.month == 10)
        {
            if (db.databass.day > 31)
            {
                yerss();
            }
        }
        if (db.databass.month == 11)
        {
            if (db.databass.day > 30)
            {
                yerss();
            }
        }
        if (db.databass.month == 12)
        {
            if (db.databass.day > 31)
            {
                //yerss();
                Debug.Log("�����⵵");
                Sccalculate();
                endCalendar();
                schdulesList = new List<string>();
                isschedules = 0;
                StopCoroutine(scheduleTime());
                db.databass.day = 1;
                schdulesDay = 0;
                statck = 0;
                db.databass.month = 1;
                db.databass.year++;
               

            }
        }
    }
    public void resetMonth()
    {

        
        isschedules = 0;
        StopCoroutine(scheduleTime());
        db.databass.day = 1;
        //schdulesDay = 0;
        statck = 0;
        db.databass.month++;
        endCalendar();
        schdulesList = new List<string>();
        
        //scdulesPanal.SetActive(false);
        //SCHDULEPENAL.SetActive(false);
    }
    public void Sccalculate()
    {
        if (db.databass.Fatigue > 600)
        {
            db.databass.Karma += 20;
            db.Calculate_t.text = db.databass.year + "�� " + db.databass.month + "��" + db.databass.day + "��" + "\n" + "ü��:" + psp + "��" + "���: " + tlpp + "��" + "����: "
                + gorcep + "��" + "����: " + decreasingp + "��" + "��ġ: " + Politicsp + "��"
                + "�ŷ�: " + Charmp + "��" + "����: " + Karmap + "��" + "�Ƿ�: " + Fatiguep + "��" + "\n" + "�ƹ��͵� �ϰ� ���� �ʾ�!!!";
        }
        else if (db.databass.Fatigue > 300)
        {
            db.Calculate_t.text = db.databass.year + "�� " + db.databass.month + "��" + db.databass.day + "��" + "\n" + "ü��:" + psp + "��" + "���: " + tlpp + "��" + "����: "
                + gorcep + "��" + "����: " + decreasingp + "��" + "��ġ: " + Politicsp + "��"
                + "�ŷ�: " + Charmp + "��" + "����: " + Karmap + "��" + "�Ƿ�: " + Fatiguep + "��" + "\n" + "������ �� ���� �� ����.";
        }
        else
        {
            db.Calculate_t.text = db.databass.year + "�� " + db.databass.month + "��" + db.databass.day + "��" + "\n" + "ü��:" + psp + "��" + "���: " + tlpp + "��" + "����: "
                + gorcep + "��" + "����: " + decreasingp + "��" + "��ġ: " + Politicsp + "��"
                + "�ŷ�: " + Charmp + "��" + "����: " + Karmap + "��" + "�Ƿ�: " + Fatiguep + "��" + "\n" + "������ ������ �ߴ�.";
        }
        StartCoroutine(updateStackUI());

        db.databass.ps += psp;
        db.databass.tlp += tlpp;
        db.databass.gorce += gorcep;
        db.databass.decreasing += decreasingp;
        db.databass.Politics += Politicsp;
        db.databass.Charm += Charmp;
        db.databass.Karma += Karmap;
        db.databass.Fatigue += Fatiguep;

        psp = 0; //ü��
        tlpp = 0; //���
        gorcep = 0; //����
        decreasingp = 0; //����
        Politicsp = 0; //��ġ
        Charmp = 0; //�ŷ�
        Karmap = 0; //����
        Fatiguep = 0; //�Ƿ�   
        //StartCoroutine(updateStackUI());
        Invoke("endShedules", 3f);
    }
    IEnumerator updateStackUI()
    {
        #region ������Ʈ ����Ʈ ui
        psp_i.fillAmount = (float)psp / (float)MAXpsp;
        tlpp_i.fillAmount = (float)tlpp / (float)MAXtlpp;
        gorcep_i.fillAmount = (float)gorcep / (float)MAXgorcep;
        decreasingp_i.fillAmount = (float)decreasingp / (float)MAXdecreasingp;
        Politicsp_i.fillAmount = (float)Politicsp / (float)MAXPoliticsp;
        Charmp_i.fillAmount = (float)Charmp / (float)MAXCharmp;
        Fatiguep_i.fillAmount = (float)Fatiguep / (float)MAXFatiguep;

        psp_t.text = psp.ToString(); //ü��
        tlpp_t.text = tlpp.ToString(); //���
        gorcep_t.text = gorcep.ToString(); //����
        decreasingp_t.text = decreasingp.ToString(); //����
        Politicsp_t.text = Politicsp.ToString(); //��ġ
        Charmp_t.text = Charmp.ToString(); //�ŷ�
        Fatiguep_t.text = Fatiguep.ToString(); //�Ƿ�   
        #endregion
        yield return new WaitForSeconds(1f);

    }
    #endregion
    void endShedules()
    {

        StartCoroutine(updateStackUI());
        scdulesPanal.SetActive(false);
        SCHDULEPENAL.SetActive(false);
        ScheduleBtManager.Instance.makeDestroy();
        db.Calculate_t.text = db.databass.year + "�� " + db.databass.month + "��" + db.databass.day + "��";

        Invoke("addgoldshow", 1f);
    }
    void addgoldshow()
    {
        itmeAdd.Instance.popupPanel.SetActive(true);
        itmeAdd.Instance.popup[0] = Instantiate(itmeAdd.Instance.popupbutton);
        itmeAdd.Instance.popup[0].transform.SetParent(itmeAdd.Instance.popuppos.transform);
        itmeAdd.Instance.popup[0].transform.localPosition = Vector3.zero;
        itmeAdd.Instance.popup[0].GetComponent<Button>().onClick.AddListener(itmeAdd.Instance.addGold);
        itmeAdd.Instance.popupText.text = "�� �뵷�� �޾ҽ��ϴ�.";
    }
}
