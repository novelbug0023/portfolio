using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class choshecsdialogue
{
    #region ȣ���� ��ȭ
    public string dialogueName;
    public string[] lovessdialogues;
    public string lovesdialogue_name;
    public Image lovescharactorimage;
    #endregion
}
public class choshecDialogue : MonoBehaviour
{
    #region �̱���
    private static choshecDialogue instance = null;
    void Awake()
    {
        if (null == instance)
        {
            //�� Ŭ���� �ν��Ͻ��� ź������ �� �������� instance�� ���ӸŴ��� �ν��Ͻ��� ������� �ʴٸ�, �ڽ��� �־��ش�.
            instance = this;

            //�� ��ȯ�� �Ǵ��� �ı����� �ʰ� �Ѵ�.
            //gameObject�����ε� �� ��ũ��Ʈ�� ������Ʈ�μ� �پ��ִ� Hierarchy���� ���ӿ�����Ʈ��� ��������, 
            //���� �򰥸� ������ ���� this�� �ٿ��ֱ⵵ �Ѵ�.
            DontDestroyOnLoad(this.gameObject);
        }
        else
        {
            //���� �� �̵��� �Ǿ��µ� �� ������ Hierarchy�� GameMgr�� ������ ���� �ִ�.
            //�׷� ��쿣 ���� ������ ����ϴ� �ν��Ͻ��� ��� ������ִ� ��찡 ���� �� ����.
            //�׷��� �̹� ���������� instance�� �ν��Ͻ��� �����Ѵٸ� �ڽ�(���ο� ���� GameMgr)�� �������ش�.
            Destroy(this.gameObject);
        }
    }
    public static choshecDialogue Instance
    {
        get
        {
            if (null == instance)
            {
                return null;
            }
            return instance;
        }
    }
    #endregion
    public GameObject[] choseBt;
    public GameObject choseBtprefab;
    public Transform choseBtpos;
    public choshecsdialogue[] chose;

    public GameObject choseNextbt;
    
    public int dialogueName;
    //public string sdialogue;
    public void showchosee()
    {
        if (lovesdilogue.Instance.chose == true)
        {
            lovesdilogue.Instance.nextDialogue = 0;
            if (GameDataBassManager.Instance.databass.lovedialogueindex == 1)
            {
                addChoseInstance(3);
                choseBt[0].GetComponent<Button>().onClick.AddListener(() => choshesBT(0));
                choseBt[0].GetComponentInChildren<Text>().text = "���� �װ� ����";
                choseBt[1].GetComponent<Button>().onClick.AddListener(() => choshesBT(1));
                choseBt[1].GetComponentInChildren<Text>().text = "���� �װ� �Ⱦ�?";
                choseBt[2].GetComponent<Button>().onClick.AddListener(() => choshesBT(2));
                choseBt[2].GetComponentInChildren<Text>().text = "���� �װ� �׳� �׷�?";
            }
        }
    }
    public void addChoseInstance(int choseInstanceIndex)
    {
        switch (choseInstanceIndex)
        {
            case 1:
                choseBt[0] = Instantiate(choseBtprefab);
                choseBt[0].transform.SetParent(choseBtpos.transform);
                choseBt[0].transform.localPosition = Vector3.zero;
                break;
            case 2:
                choseBt[0] = Instantiate(choseBtprefab);
                choseBt[0].transform.SetParent(choseBtpos.transform);
                choseBt[0].transform.localPosition = Vector3.zero;
                choseBt[1] = Instantiate(choseBtprefab);
                choseBt[1].transform.SetParent(choseBtpos.transform);
                choseBt[1].transform.localPosition = Vector3.zero;
                break;
            case 3:
                choseBt[0] = Instantiate(choseBtprefab);
                choseBt[0].transform.SetParent(choseBtpos.transform);
                choseBt[0].transform.localPosition = Vector3.zero;
                choseBt[1] = Instantiate(choseBtprefab);
                choseBt[1].transform.SetParent(choseBtpos.transform);
                choseBt[1].transform.localPosition = Vector3.zero;
                choseBt[2] = Instantiate(choseBtprefab);
                choseBt[2].transform.SetParent(choseBtpos.transform);
                choseBt[2].transform.localPosition = Vector3.zero;
                break;
            case 4:
                choseBt[0] = Instantiate(choseBtprefab);
                choseBt[0].transform.SetParent(choseBtpos.transform);
                choseBt[0].transform.localPosition = Vector3.zero;
                choseBt[1] = Instantiate(choseBtprefab);
                choseBt[1].transform.SetParent(choseBtpos.transform);
                choseBt[1].transform.localPosition = Vector3.zero;
                choseBt[2] = Instantiate(choseBtprefab);
                choseBt[2].transform.SetParent(choseBtpos.transform);
                choseBt[2].transform.localPosition = Vector3.zero;
                choseBt[3] = Instantiate(choseBtprefab);
                choseBt[3].transform.SetParent(choseBtpos.transform);
                choseBt[3].transform.localPosition = Vector3.zero;
                break;
            case 5:
                choseBt[0] = Instantiate(choseBtprefab);
                choseBt[0].transform.SetParent(choseBtpos.transform);
                choseBt[0].transform.localPosition = Vector3.zero;
                choseBt[1] = Instantiate(choseBtprefab);
                choseBt[1].transform.SetParent(choseBtpos.transform);
                choseBt[1].transform.localPosition = Vector3.zero;
                choseBt[2] = Instantiate(choseBtprefab);
                choseBt[2].transform.SetParent(choseBtpos.transform);
                choseBt[2].transform.localPosition = Vector3.zero;
                choseBt[3] = Instantiate(choseBtprefab);
                choseBt[3].transform.SetParent(choseBtpos.transform);
                choseBt[3].transform.localPosition = Vector3.zero;
                choseBt[4] = Instantiate(choseBtprefab);
                choseBt[4].transform.SetParent(choseBtpos.transform);
                choseBt[4].transform.localPosition = Vector3.zero;
                break;
        }
        
    }
    public void addtalkText()
    {
        if (GameDataBassManager.Instance.databass.lovedialogueindex == 1)
        {
            chose[0].lovessdialogues[0] = "���� �ϰ� ����";
            chose[0].lovessdialogues[1] = "����";
            chose[1].lovessdialogues[0] = "���� �ϰ� �Ⱦ�";
            chose[2].lovessdialogues[0] = "���� �ϰ� �׳� �׷�";
        }
    }


    public void choshesBT(int _dialogueName)
    {
        for (int i = 0; i < choseBt.Length; i++)
        {
            if (i == choseBt.Length)
            {
                break;
            }
            Destroy(choseBt[i].gameObject);
        }
        addtalkText();
        dialogueName = _dialogueName;
        lovesdilogue.Instance.sdialogue = chose[_dialogueName].lovessdialogues[lovesdilogue.Instance.nextDialogue];

        StartCoroutine(dialogueTime());
    }

    IEnumerator dialogueTime()
    {
        lovesdilogue.Instance.NameText.text = chose[GameDataBassManager.Instance.databass.lovedialogueindex].lovesdialogue_name;

        yield return new WaitForSeconds(0.5f);
        for (int i = 0; i <= lovesdilogue.Instance.sdialogue.Length; i++)
        {
            lovesdilogue.Instance.dialogueText.text = lovesdilogue.Instance.sdialogue.Substring(0, i);
            yield return new WaitForSeconds(0.1f);
        }
        choseNextbt.SetActive(true);
        
    }
    public void nextDialogueBt()
    {
        if (lovesdilogue.Instance.nextDialogue + 1 >= chose[dialogueName].lovessdialogues.Length)
        {
            Debug.Log("��ȭ ����");
            endDialogue();
        }
        else if (lovesdilogue.Instance.nextDialogue < chose[dialogueName].lovessdialogues.Length)
        {
            Debug.Log("������ȭ");
            choseNextbt.SetActive(false);
            lovesdilogue.Instance.nextDialogue++;
            choshesBT(dialogueName);
            //StartCoroutine(dialogueTime());
        }

    }
    void endDialogue()
    {
        lovesdilogue.Instance.nextDialogue = 0;
        StopCoroutine(dialogueTime());
        //dialogueindex++;
        lovesdilogue.Instance.dialogue_box.SetActive(false);
        choseNextbt.SetActive(false);

        //_itemindex = 0;
        //popupPanel.SetActive(false);


    }

}
