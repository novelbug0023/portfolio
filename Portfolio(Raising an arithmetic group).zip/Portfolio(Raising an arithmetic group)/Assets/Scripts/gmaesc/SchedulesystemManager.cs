using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SchedulesystemManager : MonoBehaviour
{
    #region �̱���
    private static SchedulesystemManager instance = null;
    void Awake()
    {
        if (null == instance)
        {
            //�� Ŭ���� �ν��Ͻ��� ź������ �� �������� instance�� ���ӸŴ��� �ν��Ͻ��� ������� �ʴٸ�, �ڽ��� �־��ش�.
            instance = this;

            //�� ��ȯ�� �Ǵ��� �ı����� �ʰ� �Ѵ�.
            //gameObject�����ε� �� ��ũ��Ʈ�� ������Ʈ�μ� �پ��ִ� Hierarchy���� ���ӿ�����Ʈ��� ��������, 
            //���� �򰥸� ������ ���� this�� �ٿ��ֱ⵵ �Ѵ�.
            DontDestroyOnLoad(this.gameObject);
        }
        else
        {
            //���� �� �̵��� �Ǿ��µ� �� ������ Hierarchy�� GameMgr�� ������ ���� �ִ�.
            //�׷� ��쿣 ���� ������ ����ϴ� �ν��Ͻ��� ��� ������ִ� ��찡 ���� �� ����.
            //�׷��� �̹� ���������� instance�� �ν��Ͻ��� �����Ѵٸ� �ڽ�(���ο� ���� GameMgr)�� �������ش�.
            Destroy(this.gameObject);
        }
    }
    public static SchedulesystemManager Instance
    {
        get
        {
            if (null == instance)
            {
                return null;
            }
            return instance;
        }
    }
    #endregion
    ScheduleBtManager schedulebt;
    GameDataBassManager db;

    public string schdule;
    public int schdulenum;
    public string[] schdules;

    int Calendar = 365;

    int isschedules = 0;
    int schdulesDay = 0;
    //boo isTime = 0;

    public List<string> schdulesList = new List<string>();
    public GameObject schdulesboxs;
    public Image imageSchdules;
    public GameObject schdulesboxsnull;
    public GameObject Calendars;
    public GameObject[] schdulesLayers;
    public GameObject[] NoneLayers;
    public GameObject SCHDULEPENAL;
    List<GameObject> schdulesbox= new List<GameObject>();

    public GameObject scdulesPanal;
    //=================================================
    //bool isleapyeaar;

    // Start is called before the first frame update
    void Start()
    {
        schedulebt = GameObject.Find("schdulebt").GetComponent<ScheduleBtManager>();
        db = GameObject.Find("databass").GetComponent<GameDataBassManager>();
        
    }
    public void StartCalendar()
    {
        isleapyeaar(db.year);
        lastDay(db.year, db.month);
        totalDay(db.year, db.month, db.day);
        wickday(db.year, db.month, db.day);
        //Debug.Log(db.year+"��"+db.month+"��\n");
        //Debug.Log("��    ��   ȭ   ��   ��   ��   ��\n");
        for (int i = 0; i < wickday(db.year, db.month, 1); i++)
        {
            if (i == wickday(db.year, db.month, 1))
            {
                break;
            }
            //Debug.Log("");

            //if (schdulesLayers[i] != null) { DestroyImmediate(schdulesLayers[i]); }
            NoneLayers[i] = Instantiate(schdulesboxsnull);
            NoneLayers[i].transform.SetParent(Calendars.transform);
            NoneLayers[i].transform.localPosition = Vector3.zero;
            
            //Calendars.transform.parent = schdulesLayers[i].transform.position;
            //obj.transform.parent = FindObjectOfType<Canvas>().transform;
        }
        for (int i = 0; i < lastDay(db.year, db.month)+1; i++)
        {
            if (i == schdulesLayers.Length)
            {
                break;
            }
            
            schdulesLayers[i] = Instantiate(schdulesboxs);
            //Calendars.transform.position = schdulesLayers[i].transform.position;
            schdulesLayers[i].transform.SetParent(Calendars.transform);
            schdulesLayers[i].transform.localPosition = Vector3.zero;
            schdulesLayers[i].GetComponentInChildren<Text>().text = (1 + i).ToString();
            Debug.Log(i);
            if (wickday(db.year, db.month, i) == 6 && lastDay(db.year, db.month) != i)
            {
                
                Debug.Log("\n");
            }
        }
    }
    public void endCalendar()
    {
        for (int i = 0; i < wickday(db.year, db.month, 1); i++)
        {
            if (i == wickday(db.year, db.month, 1))
            {
                break;
            }
            Destroy(NoneLayers[i]);
        }
        for (int i = 0; i < lastDay(db.year, db.month) + 1; i++)
        {
            if (i == schdulesLayers.Length)
            {
                break;
            }
            if (schdulesLayers.Length >= 29)
            {
                Destroy(schdulesLayers[29]);
                Destroy(schdulesLayers[30]);
                //Destroy(schdulesLayers[31]);
            }
            Destroy(schdulesLayers[i]);
        }
    }

    #region ����޷�
    public bool isleapyeaar(int year)
    {
        //year = db.year;
        return db.year % 4 == 0 && db.year % 100 != 0 || db.year % 400 == 0;
    }
    public int lastDay(int year, int month)
    {
        //month = db.month;
        int[] m = new int[12] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        m[1] = isleapyeaar(year) ? 29 : 28;
        return m[month - 1];
    }
    public int totalDay(int year, int month, int day)
    {
        int total = (year - 1) * 365 + (year - 1) / 4 - (year - 1) / 100 + (year - 1) / 400;
        for (int i = 1; i < month; i++)
        {
            total += lastDay(year, i);
        }
        return total + day;
    }
    public int wickday(int year, int month, int day)
    {
        return totalDay(year, month, day) % 7;
    }
    #endregion

    // Update is called once per frame
    void Update()
    {
        
    }
    public int statck = 0;
    public void addSchdules()
    {
        for (int i = 0; i < 8; i++)
        {
            if (i == 8)
            {
                break;
            }
            if (schdulesList.Count > 31)
            {
                return;
            }
            schdulesList.Add(schdules[i]);
        }

        for (int j = statck * 8; j < (8 * statck) + 8; j++)
        {
            if (j == 31)
            {
                break;
            }
            for (int i = 0; i < 8; i++)
            {
                switch (schdules[i])
                {
                    case "��������":
                        schdulesLayers[j].GetComponent<Image>().color = Color.red;
                        //schdulesDay = 0;
                        break;
                    case "��������":
                        schdulesLayers[j].GetComponent<Image>().color = Color.blue;
                        //schdulesDay = 0;
                        break;
                    case "������3":
                        schdulesLayers[j].GetComponent<Image>().color = Color.green;
                        //schdulesDay = 0;
                        break;
                    case "�����н�":
                        schdulesLayers[j].GetComponent<Image>().color = Color.grey;
                        //schdulesDay = 0;
                        break;
                    case "�����н�":
                        schdulesLayers[j].GetComponent<Image>().color = Color.black;
                        //schdulesDay = 0;
                        break;
                    case "��ġ�� �н�":
                        schdulesLayers[j].GetComponent<Image>().color = Color.clear;
                        //schdulesDay = 0;
                        break;
                    case "�ÿ��� �߱���":
                        schdulesLayers[j].GetComponent<Image>().color = Color.cyan;
                        //schdulesDay = 0;
                        break;
                    case "�ù����� ���� ������":
                        schdulesLayers[j].GetComponent<Image>().color = Color.white;
                        //schdulesDay = 0;
                        break;
                }
            }
        }
        statck++;
    }

    public void scheduleTimestart()
    {
        if (schdulesList.Count < 28)
        {
            Debug.Log("������ �� ���� �ʾҽ��ϴ�.");
        }
        else
        {
            scdulesPanal.SetActive(true);
            StartCoroutine(scheduleTime());
        }
    }
    public void b()
    {
        switch (schdulesList[db.day])
        {
            case "��������":
                imageSchdules.GetComponent<Image>().color = Color.red;
                //schdulesDay = 0;
                break;
            case "��������":
                imageSchdules.GetComponent<Image>().color = Color.blue;
                //schdulesDay = 0;
                break;
            case "������3":
                imageSchdules.GetComponent<Image>().color = Color.green;
                //schdulesDay = 0;
                break;
            case "�����н�":
                imageSchdules.GetComponent<Image>().color = Color.grey;
                //schdulesDay = 0;
                break;
            case "�����н�":
                imageSchdules.GetComponent<Image>().color = Color.black;
                //schdulesDay = 0;
                break;
            case "��ġ�� �н�":
                imageSchdules.GetComponent<Image>().color = Color.clear;
                //schdulesDay = 0;
                break;
            case "�ÿ��� �߱���":
                imageSchdules.GetComponent<Image>().color = Color.cyan;
                //schdulesDay = 0;
                break;
            case "�ù����� ���� ������":
                imageSchdules.GetComponent<Image>().color = Color.white;
                //schdulesDay = 0;
                break;
        }
        //monthkins();
    }

    IEnumerator scheduleTime()
    {
        for (int i = 0; i < 31;i++)
        {
            yield return new WaitForSeconds(1f);
            //s();
            b();
            //monthkins();
            db.day++;
            monthkins();
            //schdulesDay++;

            if (db.month > 12)
            {
                db.day = 1;
                schdulesDay = 0;
                statck = 0;
                db.month = 1;
                db.year++;
                i = 0;
            }
            if (isschedules == 1)
            {
                i = 0;
            }
            
        }
    }
    #region ���� �����ͺ��̽�
    public void monthkins()
    {
        if (db.month == 1)
        {
            if (db.day > 31)
            {
                resetMonth();
            }
        }
        if (db.month == 2)
        {
            if (db.day > 28)
            {
                resetMonth();
            }
        }
        if (db.month == 3)
        {
            if (db.day > 31)
            {
                resetMonth();
            }
        }
        if (db.month == 4)
        {
            if (db.day > 30)
            {
                resetMonth();
            }
        }
        if (db.month == 5)
        {
            if (db.day > 31)
            {
                resetMonth();
            }
        }
        if (db.month == 6)
        {
            if (db.day > 30)
            {
                resetMonth();
            }
        }
        if (db.month == 7)
        {
            if (db.day > 31)
            {
                resetMonth();
            }
        }
        if (db.month == 8)
        {
            if (db.day > 31)
            {
                resetMonth();
            }
        }
        if (db.month == 9)
        {
            if (db.day > 30)
            {
                resetMonth();
            }
        }
        if (db.month == 10)
        {
            if (db.day > 31)
            {
                resetMonth();
            }
        }
        if (db.month == 11)
        {
            if (db.day > 30)
            {
                resetMonth();
            }
        }
        if (db.month == 12)
        {
            if (db.day > 31)
            {
                resetMonth();
            }
        }
    }
    public void resetMonth()
    {
        db.day = 1;
        //schdulesDay = 0;
        statck = 0;
        db.month++;
        endCalendar();
        schdulesList = new List<string>();
        scdulesPanal.SetActive(false);
        SCHDULEPENAL.SetActive(false);
    }
    #endregion
}
